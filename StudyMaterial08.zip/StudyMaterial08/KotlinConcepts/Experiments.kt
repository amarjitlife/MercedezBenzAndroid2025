
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________

class A {
    var something = 99
    // inner companion object {
    companion object {
        fun bar() {
            // println( something )
            println("Companion object called")
        }
    }
}

fun companionObjects() {
    A.bar()
}


//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________

fun main() {
    println("\nFunction: companionObjects")
    companionObjects()

    // println("\nFunction: ")
    // println("\nFunction: ")
    // println("\nFunction: ")  
    // println("\nFunction: ")  
    // println("\nFunction: ")
    // println("\nFunction: ")
    // println("\nFunction: ")  
}




