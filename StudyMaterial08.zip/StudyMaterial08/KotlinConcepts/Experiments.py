

files = ["file1.txt", "file2.txt" ]

words = {}

for file in files:
	for line in open(file):
		for word in line.split():
			words[ word ] = words.get( word, 0 ) + 1

print( words )

