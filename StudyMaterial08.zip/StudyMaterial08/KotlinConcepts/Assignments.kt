
//_______________________________________________________
//
// DAY 01
//_______________________________________________________

ASSIGNMENTS A1: READING AND EXPLORATION ASSIGNMENTS
	Study Following Java Chapters
		Chapter 01 : Fundamental Programming Structures
		Chapter 02 : Object-Oriented Programming

	Reference: Core Java For Impatient, Cay Hortsman
	https://www.amazon.com/s?k=Java+For+Impatient&ref=nb_sb_noss

ASSIGNMENTS A2: Kotlin REVISION, CODING AND PRACTICE ASSIGNMENTS
	Practice Kotlin Code Done In Class

ASSIGNMENTS A3 : Exploration and Reasoning Assignments
		A2.1 : Divide By Zero In C/C++/Java/Python/JS
				Mathematics
		A2.2 : Modulus Operator In C/C++/Java/Python/JS
				Mathematics
		A2.3 : Floating Point Comparision In C/C++/Java/Python/JS
				Mathematics

//_______________________________________________________
//
// DAY 02
//_______________________________________________________

ASSIGNMENTS A1: READING AND EXPLORATION ASSIGNMENTS
	Study Following Java Chapters
		Chapter 02 : Object-Oriented Programming

	Reference: Core Java For Impatient, Cay Hortsman
	https://www.amazon.com/s?k=Java+For+Impatient&ref=nb_sb_noss

ASSIGNMENTS A2: Kotlin REVISION, CODING AND PRACTICE ASSIGNMENTS
	Practice Kotlin Code Done In Class

ASSIGNMENTS A3 : Exploration and Reasoning Assignments
		A2.1 : Divide By Zero In C/C++/Java/Python/JS
				Mathematics
		A2.2 : Modulus Operator In C/C++/Java/Python/JS
				Mathematics
		A2.3 : Floating Point Comparision In C/C++/Java/Python/JS
				Mathematics

//_______________________________________________________
//
// DAY 03
//_______________________________________________________


ASSIGNMENTS A1: JAVA READING AND EXPLORATION ASSIGNMENTS
	Study Following Java Chapters
		Chapter 02 : Object-Oriented Programming
		Chapter 03 : Interfaces and Lambda Expressions
				Complete Only Interfaces Topics

	Reference: Core Java For Impatient, By Cay Hortsman
	https://www.amazon.com/s?k=Java+For+Impatient&ref=nb_sb_noss

ASSIGNMENTS A2: KOTLIN REVISION, CODING AND PRACTICE ASSIGNMENTS
	Practice Kotlin Code Done In Class

ASSIGNMENTS A3: KOTLIN READING AND EXPLORATION ASSIGNMENTS
	Study Following Kotlin Chapters
		Chapter 01 : Full Chapter
		Chapter 02 : Full Chapter 
		Chapter 03 : Full Chapter 

	Reference: Kotlin in Action 2nd Edition, by Svetlana Isakova, Dmitry Jemerov
	https://www.oreilly.com/library/view/kotlin-in-action/9781617299605/

ASSIGNMENTS A4: EXPLORATION AND REASONING ASSIGNMENTS
	Simulate Some Of The Designs In Kotiln
	https://docs.swift.org/swift-book/documentation/the-swift-programming-language/enumerations/
	
	Study Java Collections
	https://docs.oracle.com/javase/8/docs/api/java/util/Collection.html

ASSIGNMENTS A5: THINKING AND YOUR EVOLUTION
	1. Can We Write A Code To Check Another Code Recursively Infinite!
	2. Can Every Recursive Solution Have Iterative Solution and Vice Versa!


//_______________________________________________________
//
// DAY 04
//_______________________________________________________

ASSIGNMENTS A1: JAVA READING AND EXPLORATION ASSIGNMENTS
	Study Following Java Chapters
		Chapter 02 : Object-Oriented Programming 		[ REVISION ]
		Chapter 03 : Interfaces and Lambda Expressions 	[ Complete It! ]

	Reference: Core Java For Impatient, By Cay Hortsman
	https://www.amazon.com/s?k=Java+For+Impatient&ref=nb_sb_noss

ASSIGNMENTS A2: KOTLIN REVISION, CODING AND PRACTICE ASSIGNMENTS
	Practice Kotlin Code Done In Class

ASSIGNMENTS A3: KOTLIN READING AND EXPLORATION ASSIGNMENTS
	Study Following Kotlin Chapters
		Chapter 03 : Full Chapter 
		Chapter 04 : Classes And Objects [ Read Till Sealed Classes ]

	Reference: Kotlin in Action 2nd Edition, by Svetlana Isakova, Dmitry Jemerov
	https://www.oreilly.com/library/view/kotlin-in-action/9781617299605/

ASSIGNMENTS A4: EXPLORATION AND REASONING ASSIGNMENTS
	Simulate Some Of The Designs In Kotiln
	https://docs.swift.org/swift-book/documentation/the-swift-programming-language/enumerations/
	
	Study Java Collections
	https://docs.oracle.com/javase/8/docs/api/java/util/Collection.html
	Explore Java Collection Architecture and Design Choices

ASSIGNMENTS A5: THINKING AND YOUR EVOLUTION
	Chapter 04 : Classes and Interfaces
	References:	Effective Java 3rd Edition, Kindle Edition,	by Joshua Bloch (Author) 

//_______________________________________________________
//
// DAY 05
//_______________________________________________________

ASSIGNMENTS A1: JAVA READING AND EXPLORATION ASSIGNMENTS
	Study Following Java Chapters
		Chapter 02 : Object-Oriented Programming 		[ REVISION ]
		Chapter 03 : Interfaces and Lambda Expressions 	[ Complete It! ]

	Reference: Core Java For Impatient, By Cay Hortsman
	https://www.amazon.com/s?k=Java+For+Impatient&ref=nb_sb_noss

ASSIGNMENTS A2: KOTLIN REVISION, CODING AND PRACTICE ASSIGNMENTS
	Practice Kotlin Code Done In Class

ASSIGNMENTS A3: KOTLIN READING AND EXPLORATION ASSIGNMENTS
	Study Following Kotlin Chapters
		Chapter 03 : Full Chapter 
		Chapter 04 : Classes And Objects [ Read Till Sealed Classes ]

	Reference: Kotlin in Action 2nd Edition, by Svetlana Isakova, Dmitry Jemerov
	https://www.oreilly.com/library/view/kotlin-in-action/9781617299605/

ASSIGNMENTS A4: EXPLORATION AND REASONING ASSIGNMENTS
	Simulate Some Of The Designs In Kotiln
	https://docs.swift.org/swift-book/documentation/the-swift-programming-language/enumerations/
	
	Study Java Collections
	https://docs.oracle.com/javase/8/docs/api/java/util/Collection.html
	Explore Java Collection Architecture and Design Choices

ASSIGNMENTS A5: THINKING AND YOUR EVOLUTION
	Chapter 04 : Classes and Interfaces
	References:	Effective Java 3rd Edition, Kindle Edition,	by Joshua Bloch (Author) 

//_______________________________________________________
//
// DAY 06
//_______________________________________________________

ASSIGNMENTS A1: JAVA READING AND EXPLORATION ASSIGNMENTS
	Study Following Java Chapters
		Chapter : Generics

	Reference: Core Java For Impatient, By Cay Hortsman
	https://www.amazon.com/s?k=Java+For+Impatient&ref=nb_sb_noss

ASSIGNMENTS A2: KOTLIN REVISION, CODING AND PRACTICE ASSIGNMENTS
	Practice Kotlin Code Done In Class

ASSIGNMENTS A3: KOTLIN READING AND EXPLORATION ASSIGNMENTS
	Study Following Kotlin Chapters
		All Chapters

	Reference: Kotlin in Action 2nd Edition, by Svetlana Isakova, Dmitry Jemerov
	https://www.oreilly.com/library/view/kotlin-in-action/9781617299605/


ASSIGNMENTS A5: THINKING AND YOUR EVOLUTION
	References:	Effective Java 3rd Edition, Kindle Edition,	by Joshua Bloch (Author) 
		All Chapters

//_______________________________________________________
//__________________________________________`_____________
//_______________________________________________________
//__________________________________________`_____________
//_______________________________________________________
//__________________________________________`_____________
//_______________________________________________________

// FUTURE WORK

Learn C++ [ THROUGHLY ]

	Level 00:
		1. Complete Reference C++, Herbt Schildt
			Focuses On Only Syntax

	Level 01:
		1. Thinking In C++, Volume I, 	Bruce Eckel
		2. Thinking In C++, Volume II, 	Bruce Eckel
			Both Books Discussion Code Design
			Anyone 
	
	Level 02:
		1. C++ Programming Language, Bjarne Stratroup
			Good Reference Book
			For 4+ Years Experience
		2. C++ Primer, Lippman

	Level 03:
		1. Effective C++, Scott Mayer
		2. More Effective C++, Scott Mayer
		3. Effective Modern C++
		4. Modern C++ Design, Andrew
		5. Exceptional C++
		6. Exceptional C++


Learn C [ THROUGHLY ]

	Level 01:
		1. The C Programming Langauge, 2nd Edition
				Kernigam and Dennis Rithice
		2. 21st Century C

Learn Java [ THROUGHLY ]

	Level 00:
		1. Complete Reference Java, Herbt Schildt
			Focuses On Only Syntax

	Level 01:
		1. Core Java For Impatient, Cay Hortsman

	Level 02:
		1. Effective Java

Software/System Design

	Level 01:
		1. Practical Object-Oriented Design: 
			An Agile Primer Using Ruby 2nd Edition by Sandi Metz
		
		2. Data Structures and Program Design in C++ First Edition
			by Robert L. Kruse (Author), Alexander J. Ryba (Author)

	Level 02:
		Agile Software Development, Principles, Patterns and Practices
			Robert Martin

	Level 03:
		Design Patterns: Elements of Reusable Object-Oriented Software 
		1st Edition
			Erich Gamma (Author), Richard Helm (Author), & 3 more

Foundational/Fundamentals Books
	
	Level 01:
		Structure and Interpretation of Computer Program, MIT
		by Harold Abelson , Gerald Jay Sussman , et al.

	Level 02
		Types and Programming Langauges, Benjamin Pierce


__________________________________________________
__________________________________________________
__________________________________________________
__________________________________________________
__________________________________________________
__________________________________________________
__________________________________________________
