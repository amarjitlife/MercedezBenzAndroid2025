/*
kotlinc -include-runtime Hello.kt -d hello.jar
java -jar nature.jar
*/


fun main() {
	println("Hello World! Welcome To Kotlin!!!")
}

