
//_______________________________________________________
//
// DAY 01
//_______________________________________________________

ASSIGNMENTS A1: READING AND EXPLORATION ASSIGNMENTS
	Study Following Java Chapters
		Chapter 01 : Fundamental Programming Structures
		Chapter 02 : Object-Oriented Programming

	Reference: Core Java For Impatient, Cay Hortsman
	https://www.amazon.com/s?k=Java+For+Impatient&ref=nb_sb_noss

ASSIGNMENTS A2: Kotlin REVISION, CODING AND PRACTICE ASSIGNMENTS
	Practice Kotlin Code Done In Class

ASSIGNMENTS A3 : Exploration and Reasoning Assignments
		A2.1 : Divide By Zero In C/C++/Java/Python/JS
				Mathematics
		A2.2 : Modulus Operator In C/C++/Java/Python/JS
				Mathematics
		A2.3 : Floating Point Comparision In C/C++/Java/Python/JS
				Mathematics


//_______________________________________________________
//
// DAY 02
//_______________________________________________________

ASSIGNMENTS A1: READING AND EXPLORATION ASSIGNMENTS
	Study Following Java Chapters
		Chapter 02 : Object-Oriented Programming

	Reference: Core Java For Impatient, Cay Hortsman
	https://www.amazon.com/s?k=Java+For+Impatient&ref=nb_sb_noss

ASSIGNMENTS A2: Kotlin REVISION, CODING AND PRACTICE ASSIGNMENTS
	Practice Kotlin Code Done In Class

ASSIGNMENTS A3 : Exploration and Reasoning Assignments
		A2.1 : Divide By Zero In C/C++/Java/Python/JS
				Mathematics
		A2.2 : Modulus Operator In C/C++/Java/Python/JS
				Mathematics
		A2.3 : Floating Point Comparision In C/C++/Java/Python/JS
				Mathematics

//_______________________________________________________
//
// DAY 03
//_______________________________________________________


ASSIGNMENTS A1: JAVA READING AND EXPLORATION ASSIGNMENTS
	Study Following Java Chapters
		Chapter 02 : Object-Oriented Programming
		Chapter 03 : Interfaces and Lambda Expressions
				Complete Only Interfaces Topics

	Reference: Core Java For Impatient, By Cay Hortsman
	https://www.amazon.com/s?k=Java+For+Impatient&ref=nb_sb_noss

ASSIGNMENTS A2: KOTLIN REVISION, CODING AND PRACTICE ASSIGNMENTS
	Practice Kotlin Code Done In Class

ASSIGNMENTS A3: KOTLIN READING AND EXPLORATION ASSIGNMENTS
	Study Following Kotlin Chapters
		Chapter 01 : Full Chapter
		Chapter 02 : Full Chapter 
		Chapter 03 : Full Chapter 

	Reference: Kotlin in Action 2nd Edition, by Svetlana Isakova, Dmitry Jemerov
	https://www.oreilly.com/library/view/kotlin-in-action/9781617299605/

ASSIGNMENTS A4: EXPLORATION AND REASONING ASSIGNMENTS
	Simulate Some Of The Designs In Kotiln
	https://docs.swift.org/swift-book/documentation/the-swift-programming-language/enumerations/
	
	Study Java Collections
	https://docs.oracle.com/javase/8/docs/api/java/util/Collection.html

ASSIGNMENTS A5: THINKING AND YOUR EVOLUTION
	1. Can We Write A Code To Check Another Code Recursively Infinite!
	2. Can Every Recursive Solution Have Iterative Solution and Vice Versa!


//_______________________________________________________
//
// DAY 04
//_______________________________________________________

ASSIGNMENTS A1: JAVA READING AND EXPLORATION ASSIGNMENTS
	Study Following Java Chapters
		Chapter 02 : Object-Oriented Programming 		[ REVISION ]
		Chapter 03 : Interfaces and Lambda Expressions 	[ Complete It! ]

	Reference: Core Java For Impatient, By Cay Hortsman
	https://www.amazon.com/s?k=Java+For+Impatient&ref=nb_sb_noss

ASSIGNMENTS A2: KOTLIN REVISION, CODING AND PRACTICE ASSIGNMENTS
	Practice Kotlin Code Done In Class

ASSIGNMENTS A3: KOTLIN READING AND EXPLORATION ASSIGNMENTS
	Study Following Kotlin Chapters
		Chapter 03 : Full Chapter 
		Chapter 04 : Classes And Objects [ Read Till Sealed Classes ]

	Reference: Kotlin in Action 2nd Edition, by Svetlana Isakova, Dmitry Jemerov
	https://www.oreilly.com/library/view/kotlin-in-action/9781617299605/

ASSIGNMENTS A4: EXPLORATION AND REASONING ASSIGNMENTS
	Simulate Some Of The Designs In Kotiln
	https://docs.swift.org/swift-book/documentation/the-swift-programming-language/enumerations/
	
	Study Java Collections
	https://docs.oracle.com/javase/8/docs/api/java/util/Collection.html
	Explore Java Collection Architecture and Design Choices

ASSIGNMENTS A5: THINKING AND YOUR EVOLUTION
	Chapter 04 : Classes and Interfaces
	References:	Effective Java 3rd Edition, Kindle Edition,	by Joshua Bloch (Author) 

//_______________________________________________________
//
// DAY 05
//_______________________________________________________

ASSIGNMENTS A1: JAVA READING AND EXPLORATION ASSIGNMENTS
	Study Following Java Chapters
		Chapter 02 : Object-Oriented Programming 		[ REVISION ]
		Chapter 03 : Interfaces and Lambda Expressions 	[ Complete It! ]

	Reference: Core Java For Impatient, By Cay Hortsman
	https://www.amazon.com/s?k=Java+For+Impatient&ref=nb_sb_noss

ASSIGNMENTS A2: KOTLIN REVISION, CODING AND PRACTICE ASSIGNMENTS
	Practice Kotlin Code Done In Class

ASSIGNMENTS A3: KOTLIN READING AND EXPLORATION ASSIGNMENTS
	Study Following Kotlin Chapters
		Chapter 03 : Full Chapter 
		Chapter 04 : Classes And Objects [ Read Till Sealed Classes ]

	Reference: Kotlin in Action 2nd Edition, by Svetlana Isakova, Dmitry Jemerov
	https://www.oreilly.com/library/view/kotlin-in-action/9781617299605/

ASSIGNMENTS A4: EXPLORATION AND REASONING ASSIGNMENTS
	Simulate Some Of The Designs In Kotiln
	https://docs.swift.org/swift-book/documentation/the-swift-programming-language/enumerations/
	
	Study Java Collections
	https://docs.oracle.com/javase/8/docs/api/java/util/Collection.html
	Explore Java Collection Architecture and Design Choices

ASSIGNMENTS A5: THINKING AND YOUR EVOLUTION
	Chapter 04 : Classes and Interfaces
	References:	Effective Java 3rd Edition, Kindle Edition,	by Joshua Bloch (Author) 

//_______________________________________________________
//
// DAY 06
//_______________________________________________________

ASSIGNMENTS A1: JAVA READING AND EXPLORATION ASSIGNMENTS
	Study Following Java Chapters
		Chapter 02 : Object-Oriented Programming 		[ REVISION ]
		Chapter 03 : Interfaces and Lambda Expressions 	[ Complete It! ]

	Reference: Core Java For Impatient, By Cay Hortsman
	https://www.amazon.com/s?k=Java+For+Impatient&ref=nb_sb_noss

ASSIGNMENTS A2: KOTLIN REVISION, CODING AND PRACTICE ASSIGNMENTS
	Practice Kotlin Code Done In Class

ASSIGNMENTS A3: KOTLIN READING AND EXPLORATION ASSIGNMENTS
	Study Following Kotlin Chapters
		Chapter 03 : Full Chapter 
		Chapter 04 : Classes And Objects [ Read Till Sealed Classes ]

	Reference: Kotlin in Action 2nd Edition, by Svetlana Isakova, Dmitry Jemerov
	https://www.oreilly.com/library/view/kotlin-in-action/9781617299605/

ASSIGNMENTS A4: EXPLORATION AND REASONING ASSIGNMENTS
	Simulate Some Of The Designs In Kotiln
	https://docs.swift.org/swift-book/documentation/the-swift-programming-language/enumerations/
	
	Study Java Object Class
	https://docs.oracle.com/javase/8/docs/api/java/lang/Object.html

ASSIGNMENTS A5: THINKING AND YOUR EVOLUTION
	Chapter 04 : Classes and Interfaces
	References:	Effective Java 3rd Edition, Kindle Edition,	by Joshua Bloch (Author) 

//_______________________________________________________
//__________________________________________`_____________
//_______________________________________________________
//__________________________________________`_____________
//_______________________________________________________
//__________________________________________`_____________

// FUTURE WORK
//_______________________________________________________
1. Structure and Interpretation Of Computer Program
		https://web.mit.edu/6.001/6.037/sicp.pdf



//__________________________________________`_____________

