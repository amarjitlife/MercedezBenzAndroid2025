
package learnJava;

import java.io.Serializable;

class OuterSer implements Serializable {
	private int rank;
	class InnerSer implements Serializable {
		protected String name;
			// ...
	}
	InnerSer io = new InnerSer();
}


OuterSer oo = new OuterSer();

oo.Serialise()
