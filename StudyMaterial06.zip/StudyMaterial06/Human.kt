/*
kotlinc -include-runtime Hello.kt -d hello.jar
java -jar nature.jar
*/

//_______________________________________________________

// class Spiderman {
// 	fun fly() 		= println("Fly Like Spiderman!")
// 	fun saveWorld() = println("Save World Like Spiderman!")
// }

// class Human : Spiderman() {
// 	fun fly() 		= super.fly()
// 	fun saveWorld() = super.saveWorld()
// }

//_______________________________________________________

// BEST PRACTICE
//		Design Towards Abstract Types Rather Types
//	Corollary
//		Design Towards Interfaces Rather Than Concrete Classes

// Interfaces
// Focus On What To Do!

// Interfaces Is An Abstract Type
//		Operation 	= { fly(), saveWorld() }
//		Range 		= {	}
interface Superpower {
	fun fly()
	fun saveWorld()
}

// Concrete Class
// Focus On When, Why, Which, Where, How...
class Spiderman : Superpower {
	override fun fly() 		 = println("Fly Like Spiderman!")
	override fun saveWorld() = println("Save World Like Spiderman!")
}

class Superman : Superpower {
	override fun fly() 		= println("Fly Like Superman!")
	override fun saveWorld() = println("Save World Like Superman!")
}

class Batman : Superpower {
	override fun fly() 		= println("Fly Like Batman!")
	override fun saveWorld() = println("Save World Like Batman!")
}

class HanumanJi : Superpower {
	override fun fly() 		 = println("Fly Like HanumanJi!")
	override fun saveWorld() = println("Save World Like HanumanJi!")
}

open class Wonderwoman {
	override fun fly() 		 = println("Fly Like Wonderwoman!")
	override fun saveWorld() = println("Save World Like Wonderwoman!")
}

//_______________________________________________________
// Using Mechanims Inheritance

// class Human : Spiderman() {
// class Human : Superman() {
// class Human : Batman() {
class Human : Wonderwoman() { // Tight Coupling
	override fun fly() 			= super.fly()
	override fun saveWorld() 	= super.saveWorld()
}

fun playWithHuman() {
	val spider = Spiderman()
	spider.fly()
	spider.saveWorld()

	val h = Human()
	h.fly()
	h.saveWorld()
}

//_______________________________________________________

// Using Mechanims Composition
//		Composition Is Alternative To Inheritance
class HumanBetter {
	// var power = Spiderman()
	// var power = Superman()	
	// var power = Batman()
	var power = Wonderwoman()
	fun fly() 			= power.fly()
	fun saveWorld() 	= power.saveWorld()
}

fun playWithHumanBetter() {
	val h = HumanBetter()
	h.fly()
	h.saveWorld()
}

//_______________________________________________________

// Using Mechanims Composition
//		Composition Is Better Than To Inheritance

// In Composition You Will Get Substraction
//			Hence Loose Coupling
///			Refactroing Possible
class HumanBest {
	var power: Superpower? = null //Loose Coupling
	fun fly() 			= power?.fly() // if ( power != null ) power.fly()
	fun saveWorld() 	= power?.saveWorld()
}

fun playWithHumanBest() {
	val h = HumanBest()
	h.fly()
	h.saveWorld()

	h.power = Spiderman()
	h.fly()
	h.saveWorld()

	h.power = Superman()
	h.fly()
	h.saveWorld()

	h.power = Batman()
	h.fly()
	h.saveWorld()

	h.power = Wonderwoman()
	h.fly()
	h.saveWorld()

	h.power = HanumanJi()
	h.fly()
	h.saveWorld()
}

//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________

fun main() {
	println("\nFunction: playWithHuman")	
	playWithHuman()

	println("\nFunction: playWithHumanBetter")
	playWithHumanBetter()

	println("\nFunction: playWithHumanBest")
	playWithHumanBest()

	// println("\nFunction: ")	
	// println("\nFunction: ")	
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")	
}




