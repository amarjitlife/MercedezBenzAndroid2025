
/*
kotlinc -include-runtime Hello.kt -d hello.jar
java -jar nature.jar
*/

//_______________________________________________________

// Function Type
//		(Int, Int) -> Int
fun sum( a: Int, b: Int ): Int  = a + b
fun sub( a: Int, b: Int ): Int  = a - b

// Higher Order Function
//		Functions Which Takes And/Or Returns Functions

// Polymorphic Function
//		Mechanism : Passing A Behaviour To Behaviour

// Function Type
//		(Int, Int, (Int, Int) -> Int) -> Int
fun calculator( a: Int, b: Int, operation: (Int, Int) -> Int ) : Int {
	return operation( a, b )
}

fun playWithCalculator() {
	val a = 50
	val b = 20
	var result: Int = 0

	result = calculator( a, b, ::sum ) // Configuring with ::sum
	println("Result : $result")

	result = calculator( a, b, ::sub ) // Configuring with ::sum
	println("Result : $result")

	val sumLambda = { a: Int, b: Int -> a + b }
	result = calculator( a, b, sumLambda ) // Configuring with sumLambda
	println("Result : $result")

	val subLambda = { a: Int, b: Int -> a - b }
	result = calculator( a, b, subLambda ) // Configuring with subLambda
	println("Result : $result")

	result = calculator( a, b, { a: Int, b: Int -> a * b } ) // Configuring with subLambda
	println("Result : $result")

}

//_______________________________________________________

data class Person(val name: String, val age: Int)

fun findTheMax(people: List<Person> ) {
    var max = 0
    var theMaximum: Person? = null

    for (person in people) {
        if ( person.age > max) {
            max = person.age
            theMaximum = person
        }
    }
    println(theMaximum)
}

fun playWithTheMax() {
    val people = listOf(Person("Alice", 29), Person("Bob", 31))
    findTheMax(people)
}

//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________

fun main() {
	println("\nFunction: playWithCalculator")
	playWithCalculator()

	// println("\nFunction: ")
	// println("\nFunction: ")	
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")	
}




