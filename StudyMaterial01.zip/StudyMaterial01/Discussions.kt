
________________________________________________________________

Write Following sum Function In C
//		It Should Return Valid Artihmatic Sum
//		Otherwise Print Can't Calcualate Sum

// DESIGN 01
	int sum( int a, int b ) {
		return a + b;
	}

________________________________________________________________

Write Following sum Function In C
//		It Should Return Valid Artihmatic Sum
//		Otherwise Print Can't Calcualate Sum

// DESIGN 02
	int sum( int a, int b ) {
		return a + b;
	}

________________________________________________________________

// DESIGN 03

signed int sum(signed int a, signed int b) {
	  signed int result = 0;

	  // Doing Type Checking and It's Called Type Safety
	  if (((b > 0) && (a > (INT_MAX - b))) ||
	      ((b < 0) && (a < (INT_MIN - b)))) {
	    	/* Handle/Print Error */
	  } else {
	    	result = a + b;
	  }
	  
	  return result;
	  /* ... */
}

________________________________________________________________

