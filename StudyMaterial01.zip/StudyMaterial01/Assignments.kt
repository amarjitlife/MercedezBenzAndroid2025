
//_______________________________________________________

// DAY 01
//_______________________________________________________

ASSIGNMENTS A1: READING AND EXPLORATION ASSIGNMENTS
	Study Following Java Chapters
		Chapter 01 : Fundamental Programming Structures
		Chapter 02 : Object-Oriented Programming

	Reference: Core Java For Impatient, Cay Hortsman
	https://www.amazon.com/s?k=Java+For+Impatient&ref=nb_sb_noss

ASSIGNMENTS A2: Kotlin REVISION, CODING AND PRACTICE ASSIGNMENTS
	Practice Kotlin Code Done In Class

ASSIGNMENTS A3 : Exploration and Reasoning Assignments
		A2.1 : Divide By Zero In C/C++/Java/Python/JS
				Mathematics
		A2.2 : Modulus Operator In C/C++/Java/Python/JS
				Mathematics
		A2.3 : Floating Point Comparision In C/C++/Java/Python/JS
				Mathematics

//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________



