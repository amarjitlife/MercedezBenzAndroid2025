/*
kotlinc include-runtime Hello.kt -d hello.jar
java -jar nature.jar
*/

//_______________________________________________________

fun helloWorld(): Unit {
	println("Hello World! Welcome To Kotlin!!!")
}

//_______________________________________________________

fun playWithHelloWorld() {
	val something = helloWorld()
	println( something )
}

//_______________________________________________________

fun playWithIfElse() {
	//1. Type Inferring
	//2. Type Binding

	val a = 10
	val b = 20

	val something = if (a > b) a else b
	println( something)

	val something1 = if (a > b) a else {}
	println( something1)

	// val something2 = if (a > b) a
	// println( something2 )

	if (a > b) println(a)
}

//_______________________________________________________

// Expression = Statement Having Return Value

// In C/C++/Java
// 		if-else Is A Statement

// In Kotlin
// 		if-else Is An Expression

fun max( a: Int, b: Int ) : Int {
	return if (a > b) a else b
}

fun maximum( a: Int, b: Int ) = if (a > b) a else b

// Following Both Are Equivalent
fun maximumAgain1( a: Int, b: Int ) = if (a > b) a else "Guten Tag!"
fun maximumAgain2( a: Int, b: Int ): Any = if (a > b) a else "Guten Tag!"

fun playWithMax() {
	val something = max( 99, 100 )
	println(something)

	val something1 = max( 99, -100 )
	println(something1)

	val something11 = maximum( 99, 100 )
	println(something11)

	val something22 = maximum( 99, -100 )
	println(something22)
}

//_______________________________________________________

// Design Principle
//		Design Towards Immutability Rather Than Mutability

// val Means Immutable
// var Means Mutable

// In Kotlin
// Compiler Will Generate Following Things
// 		1. Constructor Having 2 Arguments Of Type String and Boolean
//		2. Two Member Variables For Each name And isMarried
//		3. Getter For val Property
//		4. Getter and Setter For var Property

/// name And isMarried Are Property
class Person( val name: String, var isMarried: Boolean = false )

fun playWithPerson() {
	val gabbar = Person( "Gabbar", false )
	println( gabbar.name ) // gabbar.getName()
	println( gabbar.isMarried ) // gabbar.getIsMarried()

	// gabbar.name = "Gabbar Singh" //  error: 'val' cannot be reassigned.
	// println( gabbar.name )
	// println( gabbar.isMarried )

	val basanti = Person("Basanti", false )
	println( basanti.name)
	println(basanti.isMarried )

	basanti.isMarried = true	// basanti.setIsMarried( true )
	println( basanti.name)
	println(basanti.isMarried )

	val sambha = Person( name = "Samba", isMarried = false )
	println( sambha.name ) // gabbar.getName()
	println( sambha.isMarried ) // gabbar.getIsMarried()

	val sambha1 = Person( name = "Samba", false )
	println( sambha1.name ) // gabbar.getName()
	println( sambha1.isMarried ) // gabbar.getIsMarried()

	val sambha2 = Person( name = "Samba" )
	println( sambha2.name ) // gabbar.getName()
	println( sambha2.isMarried ) // gabbar.getIsMarried()
}

//_______________________________________________________


//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________

fun main() {
	println("\nFunction: playWithHelloWorld")
	playWithHelloWorld()

	println("\nFunction: playWithIfElse")
	playWithIfElse()

	println("\nFunction: playWithMax")
	playWithMax()

	println("\nFunction: playWithPerson")
	playWithPerson()

	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")	
}




