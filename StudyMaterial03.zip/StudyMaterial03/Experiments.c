
#include <stdio.h>

typedef struct human_type  {
	int id;
	char name[100];
	void ( *dance )();
} Human;

void doBhangra() 	{ printf("\nOyee Hoyee!!!..."); 	}
void doHipHop() 	{ printf("\nHip Hop!!!..."); 		}

void playWithHuman() {
				// Constructor	
	Human gabbar = { 420, "Gabbar Singh", doBhangra };

	printf("\nID: %d", gabbar.id );
	printf("\nName: %s", gabbar.name );
	gabbar.dance();

	Human basanti = { 100, "Basanti", doHipHop };

	printf("\nID: %d", basanti.id );
	printf("\nName: %s", basanti.name );
	basanti.dance();
}


void main() {
	playWithHuman();

}

