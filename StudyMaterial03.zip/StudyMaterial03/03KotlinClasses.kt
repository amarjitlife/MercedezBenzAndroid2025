
/*
kotlinc -include-runtime Hello.kt -d hello.jar
java -jar nature.jar
*/

//_______________________________________________________

// 03KotlinClasses.kt:13:16: error: this type is final, so it cannot be extended.
// class Button : View() {
//                ^^^^
// 03KotlinClasses.kt:14:6: error: 'click' hides member of supertype 'View' and needs an 'override' modifier.
// 	fun click() = println("Button: Clicked!...")

// In Kotlin
//		Classes Are Final By Default
//			Final Classes Can't Inherited!
//		Members Are Final By Default

// In C++/Java
//		Classes Are Open By Default
//		Members Are Open By Default

// open class View {
class View {
	// error: 'click' in 'View' is final and cannot be overridden.
	open fun click() = println("View: Clicked!...")
}

class Button : View() {
	override fun click() = println("Button: Clicked!...")
}

fun playWithInheritance() {
	val view = View()
	view.click()

	val button = Button()
	button.click()
}

//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________

fun main() {
	println("\nFunction: playWithInheritance")
	playWithInheritance()

	// println("\nFunction: ")	
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")	
}




