
import os

#//_________________________________________________________________

def countWords():
    files = [ "file1.txt", "file2.txt" ]
    words = {}

    for file in files:
        for line in open(file):
            for word in line.split():
                words[ word ] = words.get( word, 0 ) + 1

    print( words)

#//_________________________________________________________________
#//_________________________________________________________________

def haveFun( maximum ) : 
    print("Started Fun...")
    count = 1
    while count <= maximum:
        yield count
        count = count + 1
        print("Having Fun...")

counter = haveFun( 10 )

for count in counter:
    print( count )

#//_________________________________________________________________
#//_________________________________________________________________
#//_________________________________________________________________


#   countWords()

