
//> using scala 3.7.4
//_________________________________________________________

def sayHello() : Unit = {
	println("Hello, World!")
}

//_________________________________________________________

// DESIGN PRACTICE
//		Design Towards Immutability Rather Than Mutability

def playWithValAndVar() = {
	// Type Decisions
	// 1. Type Inferencing Happens From RHS Value
	// 2. Type Binding Happens To LHS Value
	val answer = 99	
	println( answer )

	// answer = 100
	println( answer )	

	val message: String = null
	println( message )
	// message = "Good Evening!"
	println( message )

	var counter = 0
	println( counter )
	counter = 99
	println( counter )

	val xmax, ymax = 100
	println(xmax)
	println(ymax)

	val prefix, suffix: String = null
	println( prefix )
	println( suffix )	
}


// int a = 20;
// int *ptr = &a;

// const int b = 90;
// const int *ptr = &b;

// int const * ptr = &b
// const int const * ptr = &b;
// const int * const ptr = &b;

//_________________________________________________________

def playWithMethods() = {
	println("Method Body...")
}

def playWithMethodsAgain =
	println("Method Body...")

def playWithFunctions = 
	playWithMethods()
	playWithMethodsAgain


//_________________________________________________________
/*
// In C/C++
void doSomething() {
	int  a=  10;
	char name[10] = "Gabbar";
	int numbers[5] = { 10, 20, 30, 40, 50};
}

In Java
 // Integer io = new Integer()
*/

def playWithSomeMethods = 
	val some1 = 1.toString() // Yields the string "1"
	println( some1 )

	val some2 = 1.to(10) // Yields Range(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
	println( some2 )

	// These two expressions are equivalent:
	val some3 = "Hello".intersect("World") // Yields "lo"
	println( some3 )

	val some4 = scala.collection.StringOps("Hello").intersect("World")
	println( some4 )

	val some5 = 99.99
	println( some5 )

	// Type conversions
	val some7 = 99.44.toInt
	println( some7 )
	
	val some8 = 99.toChar
	println( some8 )
//_________________________________________________________

def playWithLibaryFunctions() = {
	"Hello".intersect("World")
	"Bonjour".sorted // Yields the string "Bjnooru"

	import scala.math.* 

	sqrt(2) // Yields 1.4142135623730951
	pow(2, 4) // Yields 16.0
	min(3, Pi) // Yields 3.0

	// You don't have to use an import:
	scala.math.sqrt(2)

		// A method on a companion object:
	BigInt.probablePrime(100, scala.util.Random)

	// Parentheses are also used for element access: 
	val s = "Hello"
	s(4) // Yields 'o'


	// Remedy:
	val result = "Bonjour".sorted
	result(3)

	// or
	"Bonjour".sorted.apply(3)

	// These two expressions are equivalent:
	BigInt("1234567890")
	BigInt.apply("1234567890")

	// You don't need "new" to construct objects: 
	BigInt("1234567890") * BigInt("112358111321")

	// The concat method accepts any IterableOnce[Char], here from a range:
	"bob".concat('c'.to('z')) // Yields "bobcdefghijklmnopqrstuvwxyz"

	// When in doubt, try it out in the REPL or a worksheet:
	"Scala".sorted // Yields "Saacl"
}

//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________

@main
def hello(): Unit = {
	println("Function: sayHello")
	sayHello()

	println("Function: playWithValAndVar")
	playWithValAndVar()

	println("Function: playWithFunctions")
	playWithFunctions

	println("Function: playWithSomeMethods")
	playWithSomeMethods

	// println("Function: ")
	// println("Function: ")
	// println("Function: ")
	// println("Function: ")
	// println("Function: ")
	// println("Function: ")
	// println("Function: ")
}

