

// ____________________________________________________
// Experiment Following Code and THAN RAISE YOUR HAND!!

val soemthingOutside = 999

// Nested Class
// CANNOT Assess Outer Class Context, Inside Inner Class
class Car1(val carName: String) { // Also A Lambda
	val something = "Hello"

    fun doSomething() { // Member Function Is Also Lambda
        println(something)
    }

    class Engine(val engineName: String) { //

        override fun toString(): String {
            // Error cannot see outer scope, Hence Cann't Access carName
            return "$engineName in a $carName" 
            // return "$engineName"
        }
    }
}

//______________________________________________________________


// Inner Class
// Can Assess Outer Class Context, Inside Inner Class
class Car2(val carName: String) { // Outer Class
	val something = "Hello"

    inner class Engine(val engineName: String) { // Inner Class
        override fun toString(): String {
            return "$engineName engine in a $carName"
        }
    }
}   

// Nested and Inner classes
fun playWithNestedAndInnerClasses() {
    val mazda1 = Car1("mazda")
    val mazdaEngine1 = Car1.Engine("rotary")
    println(mazdaEngine1) // > rotary engine in a mazda

    val mazda = Car2("mazda")
    val mazdaEngine = mazda.Engine("rotary")
    println(mazdaEngine) // > rotary engine in a mazda
}


