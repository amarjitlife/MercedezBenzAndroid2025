
//________________________________________________________

// Design Principle
//		Always Design Toward Abstract Types Rather Than Concrete Types

// 	Corollary : Design Practice
//		Always Design Toward Interfaces Rather Than Concrete Classes

// Design Practice
//		Always Prefer Composition Over Inheritance

interface Superpower {
	void fly();
	void saveWorld();
}

class Spiderman implements Superpower {
	public void fly() { System.out.println("Fly Like Spiderman!"); }
	public void saveWorld() { System.out.println("SaveWorld Like Spiderman!"); }
}

class Superman implements Superpower {
	public void fly() { System.out.println("Fly Like Superman!"); }
	public void saveWorld() { System.out.println("SaveWorld Like Superman!"); }
}

class Heman implements Superpower {
	public void fly() { System.out.println("Fly Like Heman!"); }
	public void saveWorld() { System.out.println("SaveWorld Like Heman!"); }
}

class Wonderwoman {
	public void fly() { System.out.println("Fly Like Wonderwoman!"); }
	public void saveWorld() { System.out.println("SaveWorld Like Wonderwoman!"); }
}

//________________________________________________________

// class Human extends Spiderman {
// class Human extends Superman {
// class Human extends Heman {
class Human extends Wonderwoman {
	public void fly() 		{ super.fly(); 		}			//{ System.out.println("Fly Like Human!"); }
	public void saveWorld() { super.saveWorld(); }			//{ System.out.println("SaveWorld Like Human!"); }
}

//________________________________________________________
// Design Using Composition
//		Composition Is Alternative To Inheritance

class HumanBetter {
	// Spiderman power = new Spiderman();
	// Superman  power = new Superman();
	// Heman power = new Heman();
	Wonderwoman power = new Wonderwoman();

	public void fly() 		{ power.fly(); 		}			//{ System.out.println("Fly Like Human!"); }
	public void saveWorld() { power.saveWorld(); }			//{ System.out.println("SaveWorld Like Human!"); }
}

//________________________________________________________
// Design Using Composition
//		Composition Is Alternative To Inheritance

class HumanBest {
	Superpower power = null;
	public void fly() 		{ if (power != null ) power.fly(); 		}			//{ System.out.println("Fly Like Human!"); }
	public void saveWorld() { if (power != null ) power.saveWorld(); }			//{ System.out.println("SaveWorld Like Human!"); }
}

//________________________________________________________
//________________________________________________________


class Experiments {
	public static void main( String[] args ) {
		Human h = new Human();
		h.fly();
		h.saveWorld();

		HumanBetter hb = new HumanBetter();
		hb.fly();
		hb.saveWorld();

		System.out.println("\nLet's Do Best...");

		HumanBest best = new HumanBest();
		best.fly();
		best.saveWorld();

		best.power = new Spiderman();
		best.fly();
		best.saveWorld();

		best.power = new Superman();
		best.fly();
		best.saveWorld();

		best.power = new Heman();
		best.fly();
		best.saveWorld();
	}
}


//________________________________________________________________

class OuterSer implements Serializable {
	private int rank;
	class InnerSer implements Serializable {
		protected String name;
			// ...
	}
	InnerSer io = new InnerSer();
}


Outerser outer = new Outerser()
//Serialise outer Instance

//________________________________________________________________

class OuterSer implements Serializable {
	private int rank;
	
	static class InnerSer implements Serializable {
		protected String name;
			// ...
	}
	InnerSer io = new InnerSer();
}

//________________________________________________________________
//________________________________________________________________
//________________________________________________________________
//________________________________________________________________

