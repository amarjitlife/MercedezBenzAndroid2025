
//______________________________________________________________________

Write Following sum Function In C

// DESIGN 01
int sum( int a, int b) {
	return a + b;
}

//______________________________________________________________________


Write Following sum Function In C
	1. It Should Return Arithmatic Sum
	2. Should Print Can't Calculate For Given Values a, b

int sum( int a, int b) 

//______________________________________________________________________

// DESIGN 02
 MIN <= a, b <= MAX
 sum = a + b

 MIN <= sum <= MAX
 
//______________________________________________________________________

// DESIGN 03
long sum = a + b
INT_MIN <= sum <= INT_MAX

return sum

//______________________________________________________________________

// DESIGN 03
Based On sizeof()

//______________________________________________________________________

// DESIGN 04
	int sum = a + b
	a, b > 0 and sum < 0
	a, b < 0 and sum > 0

//______________________________________________________________________

// DESIGN 05

#include <limits.h>

int sum(signed int si_a, signed int si_b) {
  signed int sum = 0;
  // Type Safe Code
  //	Respecting Type Definition Like God
  if (((si_b > 0) && (si_a > (INT_MAX - si_b))) ||
      ((si_b < 0) && (si_a < (INT_MIN - si_b)))) {
    /* Handle error */
  } else {
    sum = si_a + si_b;
  }
  /* ... */
  return sum;
}

//______________________________________________________________________
//______________________________________________________________________
//______________________________________________________________________

https://github.com/amarjitlife/InMobiTraining
https://github.com/amarjitlife/InMobiTraining
https://github.com/amarjitlife/InMobiTraining





