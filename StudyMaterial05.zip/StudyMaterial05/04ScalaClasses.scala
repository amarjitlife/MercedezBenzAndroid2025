
//_________________________________________________________

// Best Practice
//		State Should Note Exposed
//			Hence Must Be Private
//		Expose Only Required API's For Type/Class

// In Scala
//		All Instance Members Are Public By Default

// In Java
//		All Instance Members Are Private By Default

class Counter:
	// Member Property
	private var value = 0
	// Method

	var something: Int = 99

	def increment() =
		value += 1

	// Method : Parameterless Method
	def current = value
/*
	def currenAgain = {
		value = 0
		// return value
	}
*/

def counterDemo = 
	val myCounter = Counter()
	var counterValue = myCounter.current

	println( s"Counter :: $counterValue")
	myCounter.increment()
	myCounter.increment()

	counterValue = myCounter.current
	println( s"Counter :: $counterValue")

	println( s"Something :: ${myCounter.something}" )
	myCounter.something = 777
	println( s"Something :: ${myCounter.something}" )

//_________________________________________________________

class `नमस्ते`:
	val value = "Namaskar"

	def dance() = 
		println("Doing नमस्ते Dance...")

def playWithSomeFunnyClass =
	val naman = `नमस्ते`()
	naman.dance()

//_________________________________________________________

def playWithSimpleClasses =
	counterDemo
	playWithSomeFunnyClass

//_________________________________________________________

class Person:
	private var privateAge = 0

	// Custom Getter
	def age = privateAge
	// Custom Setter
	def age_= (newValue: Int ) = 
		// Custom Validation
		if newValue > privateAge then privateAge = newValue


def playWithPerson =
	var gabbar = Person()

	println( gabbar.age ) // gabbar.age 

	gabbar.age = 30 // gabbar.age_( 30 )
	println( gabbar.age )

	gabbar.age = 31
	println( gabbar.age )

	gabbar.age = 25
	println( gabbar.age )

//_________________________________________________________

// Scala Classes Property Members
//		1. Member Variable
//		2. Accessor Methods i.e Getter and Setter
//			For Immutability Property Only Getter Generated
//			For Mutability Property Getter and Setter Generated
//		3. All Instance Members By Default Are Public

class Message:
	// Property
	//		
	val timeStamp = java.time.Instant.now
	var text = "Hello InMobians!"

def playWithMessage =
	val message = Message()
	val t = message.timeStamp   // message.timeStamp Getter Call
	val tt = message.text 		// message.text Getter Call

	println(t)

	println(message.text)
	message.text = "Good Evening!!!" // message.text_( "Good Evening!!!") Setter Call
	println( message.text )


//_________________________________________________________

def playWithLocalClass1 =
	// Local Classes
	// 		Class Defined Inside A Function
	class Counter :
		private var value = 0

		def increment() = value += 1
		def isLess(other: Counter) = value < other.value 
			// Can access private field of other object

	val first = Counter()
	val second = Counter()
	
	first.increment()
	second.increment()
	second.increment()  

	println(first.isLess(second))

	def someLocalFunction =
		println("Local Function Called...")

	someLocalFunction

//_________________________________________________________

// Localisation
//		System Property
//		Encapsulation Is Special Case Of Localisation

// Function Have Localisation

// class playWithLocalClass2:
/*
def playWithLocalClass2 =
	// Local Classes
	// 		Class Defined Inside A Function
	class Counter :
		private var value = 0

		def increment() = value += 1
		def isLess(other: Counter) = value < other.value 
			// Can access private field of other object

		def doSomething = println("Doing Something...")
	val first = Counter()
	return first
*/

def playWithLocalClassAgain =
	playWithLocalClass1
	
	// var something = playWithLocalClass2
	// something.doSomething

//_________________________________________________________

def saveToDatabase =
	// Local Function
	def validation =
		println("Local Validation Function Called...")

	validation
	validation

	// Local Classes
	// 		Class Defined Inside A Function
	class Counter :
		private var value = 0

		def increment() = value += 1
		def isLess(other: Counter) = value < other.value 
			// Can access private field of other object

	val first = Counter()
	val second = Counter()
	

//_________________________________________________________

def playWithPrimaryConstructor1 =
				// Primary Constructor With Default Arguments
	class Person( val name: String, val age: Int = 0 ):
		def description = s"$name is $age years old!"

	val gabbar = Person( "Gabbar Singh", 30 )
	println( gabbar.description )

	val gabbarKidu = Person( "Young Gabbar Singh", 0 )
	println( gabbarKidu.description )


//_________________________________________________________

// Consistent Constructor Design
//		Full Constructor
//			Which Initialised All The Properties
//
//		Full Constructor Within Class
//			Should Call Full Constructor From Parent Class
//
//		All Other Convenience Constructors Within Class
//			Should Call Full Constructor Within Class

def playWithAuxularyConstructor1 =

	class Person:
		private var name: String = ""
		private var age: Int = 0

		// Constructor Overloading
		def this( name: String ) =
			this()
			this.name = name

		def this( name: String, age: Int ) =
			// this( name )
			this()
			this.name = name
			this.age = age

		def description = s"$name is $age years old!"

	val gabbar1 = Person( "Gabbar Singh" )
	println( gabbar1.description )

	val gabbar2 = Person( "Gabbar Singh", 30 )
	println( gabbar2.description )

	val gabbarKidu = Person( "Young Gabbar Singh", 0 )
	println( gabbarKidu.description )


//_________________________________________________________

/*
def playWithReflexiveLawViolation =
	var title = ""
				// Primary Constructor With Default Arguments
	class Person:
		var name: String = title
		var age: Int = 0

		def this( name: String, age: Int ) =
			this.name = this.name + name
			this.age = age

		def description = s"$name is $age years old!"

	val gabbar = Person( "Gabbar Singh", 30 )
	println( gabbar.description )

	title = "Dr."

	println( gabbar.description )
*/

//_________________________________________________________

def playWithPrimaryConstructor2 =
	// The primary constructor executes all statements 
	//			in the class definition
	class Person(val name: String, val age: Int) :
		println("Just constructed another person")

		def description = s"$name is $age years old"
	
	val p1 = Person("Fred", 42)
	// println(p1.description)       
	// val p2 = Person("Wilma", 39)
	// println(p2.description)       

//_________________________________________________________

def playWithPrimaryConstructor3 =
	// With default arguments, you may not need auxiliary constructors:

	class Person(val name: String = "", val age: Int = 0) :
		def description = s"$name is $age years old"

	val p = Person()
	println(p.description)

//_________________________________________________________

def playWithPrimaryConstructor4 =
	// Primary constructor parameters without val or var don't have a getter
	class Person(firstName: String, lastName: String, age: Int) :
		val name = firstName + " " + lastName
		def description = s"$name is $age years old"

	val p = Person("Fred", "Flintstone", 42)
	println(p.description)
	// Cannot refer to p.firstName, p.lastName, p.age
	// firstName, lastName not stored in the object
	// age is stored because it is needed in description

//_________________________________________________________

def playWithPrimaryConstructor5 =
	// This primary constructor is private
	class Person private(val id: Int) :
		private var name = ""

		def this(name: String, id: Int) =
			this(id)
			this.name = name
		
		def description = s"$name has id $id"

	val p = Person("Fred", 42)
	println(p.description)

//_________________________________________________________

import scala.collection.mutable.ArrayBuffer

def playWithNestedClasses1 =

	class Network: // Enclosing Context
		var name: String = "inMobiNetwork"
		// Class Inside Class
		class Member(val name: String): // Enclosed Context
			val contacts = ArrayBuffer[Member]()

			def description = println(s"$name : Member")

		private val members = ArrayBuffer[Member]()

		def join( name: String ) = // Enclosing Context
			val member = Member( name )
			members += member
			member

		val testMember = Member("Test")
		testMember.description

	val chatting = Network()
	val facebook = Network()

	val gabbar 	= facebook.join("Gabbar Singh")
	val basanti = chatting.join("Basanti")

// 	basanti.contacts += gabbar

// [error] ./04ScalaClasses.scala:361:22
// [error] Found:    (gabbar : facebook.Member)
// [error] Required: chatting.Member
// [error] 	basanti.contacts += gabbar
// [error]                      ^^^^^^

//_________________________________________________________

// Here we use a Type Projection. 
//		Each network collects its own members,
// 		but contacts are members of any network.
def playWithNestedClasses2 = 
	class Network :
		class Member(val name: String) :
			val contacts = ArrayBuffer[Network#Member]()  
			
		private val members = ArrayBuffer[Member]()
	
		def join(name: String) =
			val m = new Member(name)
			members += m
			m  

	val chatter = Network()
	val myFace = Network()

	val m = chatter.Member("Fred")

	val fred = chatter.join("Fred")
	val wilma = chatter.join("Wilma")
	fred.contacts += wilma // Ok
	val barney = myFace.join("Barney") 
	fred.contacts += barney // Also ok


//_________________________________________________________

// Static Use Cases In Java
// 1. Singleton
// 2. Factory Method

// 3. Constants static final
// 4. static main 
// 5. Class Members Initialisation

class Congress {
	static val gandhi = Mahathma()

	static def doFunctions() {

	}
}

// 6. Utility Methods
// 7. Static Imports
// 8. To Bind Things With Class/Type
// 9. Counting Objects
class ObjectManager {
	var objectCount = 0
	//Object Creation/Destruction
	//		Counting
}

val manager = ObjectManager()

// 10. Global Objects

// 11. Communication Betwwen The Objects
// and ....


//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________
//_________________________________________________________

@main
def scalaClasses(): Unit = {
	println("\nFunction: playWithSimpleClasses")
	playWithSimpleClasses

	println("\nFunction: playWithPerson")
	playWithPerson

	println("\nFunction: playWithMessage")
	playWithMessage

	// println("\nFunction: playWithLocalClass")
	// playWithLocalClass

	println("\nFunction: playWithLocalClassAgain")
	playWithLocalClassAgain

	println("\nFunction: playWithPrimaryConstructor1")
	playWithPrimaryConstructor1

	println("\nFunction: playWithAuxularyConstructor1")
	playWithAuxularyConstructor1

	// println("\nFunction: playWithReflexiveLawViolation")
	// playWithReflexiveLawViolation

	println("\nFunction: playWithPrimaryConstructor2")
	playWithPrimaryConstructor2

	println("\nFunction: playWithNestedClasses1")
	playWithNestedClasses1

	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")
}


