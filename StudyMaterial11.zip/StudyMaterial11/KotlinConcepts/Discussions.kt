
________________________________________________________________

Write Following sum Function In C
//		It Should Return Valid Artihmatic Sum
//		Otherwise Print Can't Calcualate Sum

// DESIGN 01
	int sum( int a, int b ) {
		return a + b;
	}

________________________________________________________________

Write Following sum Function In C
//		It Should Return Valid Artihmatic Sum
//		Otherwise Print Can't Calcualate Sum

// DESIGN 02
	int sum( int a, int b ) {
		return a + b;
	}

________________________________________________________________

// DESIGN 03

signed int sum(signed int a, signed int b) {
	  signed int result = 0;

	  // Doing Type Checking and It's Called Type Safety
	  if (((b > 0) && (a > (INT_MAX - b))) ||
	      ((b < 0) && (a < (INT_MIN - b)))) {
	    	/* Handle/Print Error */
	  } else {
	    	result = a + b;
	  }
	  
	  return result;
	  /* ... */
}

________________________________________________________________

fun f1()
{
	f11()
	f12()
}

fun f2()
{
	f21()
	f22()
	f23()
}

fun main() 
{
	f1()
	f2()
}
________________________________________________________________


{ // E
	{ // E1
		{ // E11

		}

		{ // E12

		}
	}

	{ // E2
		{ // E21

		}
		{ // E22

		}
		{ // E23

		}

	}
}

________________________________________________________________

int a = 2147483647; //903903903;
int b = 10 ;

int c;

try {
	c = a + b; //???
} catch {

}
________________________________________________________________

Extension Functions vs. Class Member

________________________________________________________________

{ // λ, C
	{ // λ1, C1
		{ // λ11, C11

		}

		{ // λ12, C12

		}
	}

	{ // λ2, C2
		{ // λ21, C21

		}
		{ // λ22, C21

		}
		{ // λ23, C22

		}

	}
}

________________________________________________________________
________________________________________________________________
________________________________________________________________
________________________________________________________________
________________________________________________________________

//	Questions 01
//		How Cancellation Of Coroutine Internally Works?

//	Questions 02
//		Unconfined Coroutine Can Be Rescheduled On Any Thread
//		Or Any Limitations

//	Questions 03
//		Custom Dispatcher

________________________________________________________________

