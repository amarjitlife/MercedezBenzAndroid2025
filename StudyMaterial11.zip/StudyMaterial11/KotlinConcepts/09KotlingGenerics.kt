
import java.util.Random

//_____________________________________________________

// E Is Type Place Holder
// MutableStack Is Generic Type i.e. Template

//	Generics Are Templates Programming
//		In Mathematics It's Callled Parameterised Types
//		Write Code To Generate Code
//		Compile Time Polymorphism

class MutableStack<E>( vararg items: E ) {              
	private val elements = items.toMutableList()
	fun push(element: E) = elements.add(element)        
	fun peek(): E = elements.last()                     
	fun pop(): E = elements.removeAt(elements.size - 1)
	fun isEmpty() = elements.isEmpty()
	fun size() = elements.size
	override fun toString() = "MutableStack(${elements.joinToString()})"
}


// // Compiler Generatged Code On Demand Basis
// //		Based On The Usage
// class MutableStack<Int>( vararg items: Int ) {              // 1
//   private val elements = items.toMutableList()
//   fun push(element: Int) = elements.add(element)        // 2
//   fun peek(): Int = elements.last()                     // 3
//   fun pop(): Int = elements.removeAt(elements.size - 1)
//   fun isEmpty() = elements.isEmpty()
//   fun size() = elements.size
//   override fun toString() = "MutableStack(${elements.joinToString()})"
// }


// // Compiler Generatged Code On Demand Basis
// //		Based On The Usage
// class MutableStack<String>( vararg items: String ) {              // 1
//   private val elements = items.toMutableList()
//   fun push(element: String) = elements.add(element)        // 2
//   fun peek(): String = elements.last()                     // 3
//   fun pop(): String = elements.removeAt(elements.size - 1)
//   fun isEmpty() = elements.isEmpty()
//   fun size() = elements.size
//   override fun toString() = "MutableStack(${elements.joinToString()})"
// }

fun playWithMutableStack() {
	// Type Inferred and Substitued At Type Place Holder <E> At Compile Time
	val stackInts = MutableStack<Int>( 10, 20, 30 )
	println( stackInts.size() ) 
	stackInts.push( 100 )
	stackInts.push( 200 )
	println( stackInts.size() ) 
	println( stackInts.pop() )	

	val stackStrings = MutableStack<String>( "Ding", "Dong" )
	println( stackStrings.size() ) 
	stackStrings.push( "Ting" )
	stackStrings.push( "Tong" )
	println( stackStrings.size() ) 
	println( stackStrings.pop() )	
}

//_____________________________________________________


class Temperature(var tempInCelsius: Float)

// Extension Properties 
var Temperature.tempInFahrenheit: Float
    get() = (tempInCelsius * 9 / 5) + 32
    set(value) {
        tempInCelsius = (value - 32) * 5 / 9
    }

fun playWithExtensionProperties() {
    val temp = Temperature(32f)
	println( temp.tempInFahrenheit )

	temp.tempInFahrenheit = 90f
	println( temp.tempInCelsius )
}

//_____________________________________________________

// Generic Extention Property

val <T> List<T>.penultimate: T
	get() = this[ size - 2 ]


fun playWithGenericProperty() {
	val list = listOf( 10, 20, 30, 40)
	println( "Value : ${ list.penultimate }")

	val listAgain = listOf( "Ding", "Dong", "Ting", "Tong")
	println( "Value : ${ listAgain.penultimate }")
}

//_____________________________________________________

open class Animal( val type : String  ) 
open class Pet( val name : String, type: String ) : Animal( type )

class Cat( name : String, type: String ) : Pet( name, type ) 
open class Dog( name : String, type: String ) : Pet( name, type ) 
class GermanShaperd( name : String, type: String ) : Dog( name, type ) 

// Polymorpic Functions
//		Using Mechanism: Passing Parent Type From Hierarcy
//			Can Pass Pet and Pet Child Types
fun chooseFavoriteNonGeneric( pets: List<Pet> ) : Pet {
	val random = Random()
    val favorite = pets[ random.nextInt( pets.size ) ]
    println("${favorite.name} is the favorite")
    return favorite
}

// fun <T> chooseFavorite( pets: List<T> ): T {
//		 error: unresolved reference 'name'

// Polymorphic Function
//		Compile Time Polymorphism
//		Compiler Will Generate Copy Code After 
///			Inferrering/Subtituting Type At Compile Time

// Type Bounds
//		T Can Be Any Type Whose Super Type Is Pet
//		Or Any Sub Type Of Pet
fun <T : Pet> chooseFavorite(pets: List<T> ): T {
	val random = Random()
    val favorite = pets[ random.nextInt( pets.size ) ]
    println("${favorite.name} is the favorite")
    return favorite
}

fun playWithChooseFavorite() {
	val catsAgain: List<Cat> = listOf( Cat("Whiskers", "Cat"), Cat("Rosie", "Cat") )
	val favoriteAgain = chooseFavoriteNonGeneric( catsAgain )
	println( "Favorite Name : ${ favoriteAgain.name }" )

	val dogs1: List<Dog> = listOf( Dog( "Indian Dog!", "Dog"), Dog("Hound", "Dog"),
								Dog("BitBull", "Dog"), Dog("Pug", "Dog"),
								GermanShaperd("German GermanShaperd", "Dog") )
	val favoriteOnceAgain = chooseFavoriteNonGeneric( dogs1 )
	println( "Favorite Name : ${ favoriteOnceAgain.name }" )

	val cats1: List<Cat> = listOf( Cat("Whiskers", "Cat"), Cat("Rosie", "Cat") )
	val favorite1 = chooseFavorite( cats1 )
	println( "Favorite Name : ${ favorite1.name }" )

	val dogs2: List<Dog> = listOf( Dog( "Indian Dog!", "Dog"), Dog("Hound", "Dog"),
								Dog("BitBull", "Dog"), Dog("Pug", "Dog"),
								GermanShaperd("German GermanShaperd", "Dog") )
	val favorite2 = chooseFavorite( dogs2 )
	println( "Favorite Name : ${ favorite2.name }" )

	val animals: List<Animal> = listOf( Animal("Fish"), Animal("Bird"), Animal("Mammal") )
	for (animal in animals) println( animal.type )

 	// error: type mismatch: inferred type is Animal but Pet was expected
	// val favoriteAgain2 = chooseFavorite( animals )
	// print( favoriteAgain2 )
}

//_____________________________________________________

// Boundless Generic Function
//		i.e. T Place Holder Can Be Substited With Any Type T
fun <T> equalsResult( first: T, second : T ) : Boolean  {
	return first == second
}

fun playWithEqualResults() {
	val first0 = 10
	val second0 = 100
	println( equalsResult( first0, second0 ) )

	val first1 = 10.90
	val second1 = 100.90
	println( equalsResult( first1, second1 ) )

	val first2 = Cat("Catie", "Cat")
	val second2 = Cat("Batie", "Cat")
	println( equalsResult( first2, second2 ) )
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

// error: unresolved reference. None of the following candidates is 
//		applicable because of a receiver type mismatch:
// fun < T > max( first: T, second : T ) : T {
fun < T : Comparable<T> > max( first: T, second : T ) : T {
	return if ( first > second ) first else second
}

fun playWithGenericMax() {
	val maxValue0 = max( "Kotlin", "Java" )
	println( maxValue0 )

	val maxValue1 = max( 900, 100 )
	println( maxValue1 )

	val maxValue2 = max( 90.90, 100.100 )
	println( maxValue2 )
}

//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

// Mutiple Type Parameters viz. T and U
fun < T : Pet, U : Human > chooseFavoriteMultiples( pets: List<T>, owners : List<U> ) : T {
	val random = Random()
	val owner = owners[ random.nextInt( owners.size ) ]
    val favorite = pets[ random.nextInt( pets.size ) ]

    println("${ favorite.name } is ${ owner.name } Favorite")
    return favorite
}

fun playWithChooseFavoriteMultiples() {
	val cats: List<Cat> = listOf( Cat("Whiskers", "Cat"), Cat("Rosie", "Cat") )
	val owners: List<Owner> = listOf( Owner("Himnanshu"), Owner("Shubra") )

	val favorite = chooseFavoriteMultiples( cats, owners )
	println( "Favorite Name : ${ favorite.name }" )
}

//_______________________________________________________________

fun <T> chooseFavoriteWhere(pets: List<T>): T where T : Pet {
	val random = Random()
    val favorite = pets[random.nextInt(pets.size)]
    println("${favorite.name} is the favorite")
    return favorite
}

// Following Both Signatures Are Equivalent!
// fun <T : Pet, U : Human> chooseFavoriteMultiplesWhere(pets: List<T>, owners: List<U>): T {
fun <T, U> chooseFavoriteMultiplesWhere(pets: List<T>, owners: List<U>): T where T : Pet, U : Human {
    val random = Random()
    val owner = owners[random.nextInt(owners.size)]
    val favorite = pets[random.nextInt(pets.size)]
    println("${favorite.name} is ${owner.name}'s favorite")
    return favorite
}

// “If a type parameter has multiple constraints, 
// they all need to be placed in the ‘where’ clause” 

// // fun <T : Animal> chooseFavorite(pets: List<T>): T 
// 		where T : Named {
// 		 /* ... */ 
// } 

//_______________________________________________________________

// Default Constraint
// If you don’t specify a constraint, the default constraint will be Any?.

fun <T> chooseFavoriteDefault(things: List<T>) : T { 
	/* ... */ 
}

// is the exactly the same as
fun <T : Any?> chooseFavoriteDefaultAgain(things: List<T>) : T { 
	/* ... */ 
}


// Nullable Constraints
// If you want to specify a nullable type for the constraint, 
// it’ll work as expected:

fun <T : Pet?> chooseFavoriteNullablePet(pets: List<T>): T {
    val favorite = pets[random.nextInt(pets.size)]
    println("${favorite?.name ?: "Nobody"} is the favorite")
    return favorite
}

// Any Non-Null
// Naturally, if you want to accept any type that isn’t null, 
// you’d just use Any as the constraint:
fun <T : Any> chooseFavoriteNonNullableAny(things: List<T>): T { 
	/* ... */ 
}

fun playWithChooseFavoriteNullable() {
	val maybeCats: List<Cat?> = listOf(Cat("Whiskers"), null, Cat("Rosie"))
	val favorite: Cat? = chooseFavorite(maybeCats)

	// Just remember that the ? goes on the type constraint, 
	// not the type parameter references. 
	// In other words, in this example, you 
	// wouldn’t specify List<T?> or return T?.
}


//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

fun main( ) {
	println("\nFunction : playWithChooseFavorite")
	playWithChooseFavorite()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}
