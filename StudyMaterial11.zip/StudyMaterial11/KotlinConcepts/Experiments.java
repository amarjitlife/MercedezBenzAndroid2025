
package learnJava;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Collections;

//________________________________________________________________

class OuterSer implements Serializable {
	private int rank;
	class InnerSer implements Serializable {
		protected String name;
			// ...
	}
	InnerSer io = new InnerSer();
}


Outerser outer = new Outerser()
//Serialise outer Instance


//________________________________________________________________

class JavaHeapDemo {

	public static void playWithJavaCollections() {
		List<String> words = new ArrayList<>();
		List<?> elements = words;

		System.out.println("Casting To List<Integer>");
		// List<Integer> numbers = elements;
		// List<Object> numbers = elements;

		// Note: Experiments.java uses unchecked or unsafe operations.
		@SuppressWarnings("unchecked")
		List<Integer> numbers = ( List<Integer> ) elements;
		System.out.println("Casting To List<Integer> :: Successful!");

		numbers.add( 444 );
		System.out.println("Integer Addition: Success");
		String word = words.get( 0 );
		System.out.println("String Removal: Success");
		System.out.println("Word : "+ word);
	}


	public static void playWithJavaCollectionsAgain() {
		List<String> words = new ArrayList<String>();
		System.out.println("Casting To List<Object>");

		// In Java Paramerized Types Are Invariant In Nature
		 // error: incompatible types: List<String> cannot be converted to List<Object>
		// List<Object> wordsAgain = words;
		List<Object> wordsAgain = (List<Object> ) words;

		List<Integer> numbers = ( List<Integer> ) wordsAgain;
		System.out.println("Casting To List<Integer> :: Successful!");

		// numbers.add( 444 );
		// System.out.println("Integer Addition: Success");
		// String word = words.get( 0 );
		// System.out.println("String Removal: Success");
		// System.out.println("Word : "+ word);
	}
	
}

//________________________________________________________________
//________________________________________________________________
//________________________________________________________________
//________________________________________________________________
//________________________________________________________________

public class Experiments {
	public static void playWithSerialisation() {
		OuterSer oo = new OuterSer();
		// oo.Serialise();
	}

	public static void playWithJavaHeap() {
		JavaHeapDemo.playWithJavaCollections();
		JavaHeapDemo.playWithJavaCollectionsAgain();
	}

	public static void main( String[] args ) {
		System.out.println("\nFunction: playWithSerialisation");
		playWithSerialisation();

		System.out.println("\nFunction: playWithJavaHeap");
		playWithJavaHeap();

		// System.out.println("\nFunction: ");
		// System.out.println("\nFunction: ");
		// System.out.println("\nFunction: ");
		// System.out.println("\nFunction: ");
		// System.out.println("\nFunction: ");
	}
} 

//________________________________________________________________
