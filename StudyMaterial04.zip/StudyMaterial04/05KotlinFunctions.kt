


/*
kotlinc -include-runtime Hello.kt -d hello.jar
java -jar nature.jar
*/

//_______________________________________________________

// Function Type
//		(Int, Int) -> Int
fun sum( a: Int, b: Int ): Int  = a + b
fun sub( a: Int, b: Int ): Int  = a - b

// Function Type
//		(Int, Int, (Int, Int) -> Int) -> Int
fun calculator( a: Int, b: Int, operation: (Int, Int) -> Int ) : Int {
	return operation( a, b )
}

fun playWithCalculator() {
	val a = 50
	val b = 20
	var result: Int = 0

	result = calculator( a, b, ::sum )
	println("Result : $result")

	result = calculator( a, b, ::sub )
	println("Result : $result")
}

//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________

fun main() {
	println("\nFunction: playWithCalculator")
	playWithCalculator()

	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")	
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")	
}




