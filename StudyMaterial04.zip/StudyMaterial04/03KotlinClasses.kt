
/*
kotlinc -include-runtime Hello.kt -d hello.jar
java -jar nature.jar
*/

//_______________________________________________________

// Language Design Principles
//		Brings Most Common Practices As Part Of Language Design

// BEST PRACTICE
//		Design Towards Immutability Rather Mutability

// Corollary
//		Classes Are Not Meant To Be Inherited Must Be Final
//

// 03KotlinClasses.kt:13:16: error: this type is final, so it cannot be extended.
// class Button : View() {
//                ^^^^
// 03KotlinClasses.kt:14:6: error: 'click' hides member of supertype 'View' and needs an 'override' modifier.
// 	fun click() = println("Button: Clicked!...")

// In Kotlin
//		Classes Are Final By Default
//			Final Classes Can't Inherited!
//		Members Are Final By Default

// In C++/Java
//		Classes Are Open By Default
//		Members Are Open By Default

// class View {
	// error: 'click' in 'View' is final and cannot be overridden.
open class View {
	open fun click() = println("View: Clicked!...")
	open fun magic() = println("View: Magic!...")
}

class Button : View() {
	override fun click() = println("Button: Clicked!...")
	override fun magic() = println("Button: Magic!...")
	fun doFun() = println("Button: doFun!...")
}
// Adding Functionality
// Using Extention Functions
//		Extension Function Doesn't Participates In Overridding
fun View.showOff() 		= println("View: showOff!...")
// fun Button.showOff() 	= println("Button: showOff!...")

fun playWithInheritance() {
	// val v: View = View()
	val v = View()
	v.click()
	v.magic()
	v.showOff()

	// val b: Button = Button()
	val b = Button()
	b.click()
	b.magic()
	b.showOff()
	b.doFun()

	// Object Can Have Multiple Types
	//		va Object Has Two Types Button and View Types
	// 		Child Call Object Can Be Stored In Parent Class Reference
	val va: View = Button() 
	va.click()
	va.magic()
	va.showOff()
	// va.doFun() // error: unresolved reference 'doFun'
}


//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

interface Clickable2 {
    fun click()
}

class Button2 : Clickable2 {
    override fun click() = println("I was clicked")
}

fun functionButtonClick() {
    Button2().click()
}


//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

interface Clickable3 {
    fun click()
    fun showOff() = println("I'm clickable!")
}

// Compiler Generate Following Interface and Class
//		To Work With < Java8
// interface Clickable3 {
//     fun click()
//     fun showOff()
// }

// class Clickable3Class implements Clickable3 {
//     fun click()
//     fun showOff() = println("I'm clickable!")
// }

interface Focusable3 {
    fun setFocus(b: Boolean) =
        println("I ${if (b) "got" else "lost"} focus.")

    fun showOff() = println("I'm focusable!")
}

class Button3 : Clickable3, Focusable3 {
    override fun click() = println("I was clicked")

    override fun showOff() {
        super<Clickable3>.showOff()
        super<Focusable3>.showOff()
    }
}

fun functionButtonClickableAndFocusable() {
    val button = Button3()
    button.showOff()
    button.setFocus(true)
    button.click()
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

enum class Colour {
	RED, GREEN, BLUE, YELLOW, ORANGE, UKNOWN
}

fun mixColours(c1 : Colour, c2: Colour ) = when ( setOf(c1, c2) ) {
	setOf( Colour.BLUE, Colour.GREEN ) 	-> Colour.YELLOW
	setOf( Colour.RED, Colour.YELLOW )  -> Colour.ORANGE
	// else -> throw Exception("Dirty Colour!")
	// else -> "Unknown Colour"
	else -> Colour.UKNOWN
}

fun playWithColourMixing() {
	println( mixColours( Colour.GREEN, Colour.BLUE ) )
	println( mixColours( Colour.YELLOW, Colour.RED ) )
	// println( mixColours( Colour.GREEN, Colour.RED ) )	
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

interface Expr
class Num(val value: Int) : Expr
class Sum(val left: Expr, val right: Expr) : Expr 

fun evaluate(e: Expr) : Int = when(e) {
	is Num -> e.value
	is Sum -> evaluate(e.left) + evaluate(e.right)
	else -> throw IllegalArgumentException("Unknown Expression")
}

fun playWithEvaluate() {
	// 100 + 200
	println( evaluate(Sum( Num(100), Num(200) ) ) )

	// (100 + 200) + 99
    println( evaluate(Sum(Sum(Num(100), Num(200)), Num(99))))
}

//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

sealed class Expr1 {
	class Num(val value: Int) : Expr1()
	class Sum(val left: Expr1 , val right: Expr1 ) : Expr1() 
}

fun evaluateAgain( e: Expr1 ) : Int = when(e) {
	is Expr1.Num -> e.value
	is Expr1.Sum -> evaluateAgain(e.left) + evaluateAgain(e.right)
	// else -> throw IllegalArgumentException("Unknown Expression")
}

fun playWithEvaluateAgain() {
	// 100 + 200
	println( evaluateAgain( Expr1.Sum( Expr1.Num(100), Expr1.Num(200) ) ) )

	// (100 + 200) + 99
    println( evaluateAgain( Expr1.Sum( Expr1.Sum( Expr1.Num(100), 
    	Expr1.Num(200)), Expr1.Num(99))))
}

//_________________________________________________________
// Assume Library Code
class File(name: String)
class DataSource( source: String )

sealed interface Error
sealed class IOError() : Error
class FileReadError( val file: File ) : IOError()
class DatabaseError( val source: DataSource ) : IOError()

// Assume Library Code Consumer
fun handleError( e: Error ) = when( e ) {
	is FileReadError -> { println("Error While File Reading!") }
	is DatabaseError -> { println("Error While Database Dealing!") }
	// else -> 
	//	error: 'when' expression must be exhaustive. 
	//			Add the 'is DatabaseError' branch or an 'else' branch.
}

fun playWithHandleError() {
	val file = File(name = "data.txt")
	val source = DataSource( source = "employee.db")
	
	val fileReadError = FileReadError(file)
	val databaseError = DatabaseError(source)

	handleError( fileReadError )
	handleError( databaseError )
}



//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________

fun main() {
	println("\nFunction: playWithInheritance")
	playWithInheritance()

	// println("\nFunction: ")	
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")	
}




