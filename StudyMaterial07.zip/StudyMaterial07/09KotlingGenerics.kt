
//_____________________________________________________


// E Is Type Place Holder
// MutableStack Is Generic Type i.e. Template

//	Generics Are Templates Programming
//		In Mathematics It's Callled Parameterised Types
//		Write Code To Generate Code
//		Compile Time Polymorphism

class MutableStack<E>( vararg items: E ) {              
	private val elements = items.toMutableList()
	fun push(element: E) = elements.add(element)        
	fun peek(): E = elements.last()                     
	fun pop(): E = elements.removeAt(elements.size - 1)
	fun isEmpty() = elements.isEmpty()
	fun size() = elements.size
	override fun toString() = "MutableStack(${elements.joinToString()})"
}


// // Compiler Generatged Code On Demand Basis
// //		Based On The Usage
// class MutableStack<Int>( vararg items: Int ) {              // 1
//   private val elements = items.toMutableList()
//   fun push(element: Int) = elements.add(element)        // 2
//   fun peek(): Int = elements.last()                     // 3
//   fun pop(): Int = elements.removeAt(elements.size - 1)
//   fun isEmpty() = elements.isEmpty()
//   fun size() = elements.size
//   override fun toString() = "MutableStack(${elements.joinToString()})"
// }


// // Compiler Generatged Code On Demand Basis
// //		Based On The Usage
// class MutableStack<String>( vararg items: String ) {              // 1
//   private val elements = items.toMutableList()
//   fun push(element: String) = elements.add(element)        // 2
//   fun peek(): String = elements.last()                     // 3
//   fun pop(): String = elements.removeAt(elements.size - 1)
//   fun isEmpty() = elements.isEmpty()
//   fun size() = elements.size
//   override fun toString() = "MutableStack(${elements.joinToString()})"
// }

fun playWithMutableStack() {
	// Type Inferred and Substitued At Type Place Holder <E> At Compile Time
	val stackInts = MutableStack<Int>( 10, 20, 30 )
	println( stackInts.size() ) 
	stackInts.push( 100 )
	stackInts.push( 200 )
	println( stackInts.size() ) 
	println( stackInts.pop() )	

	val stackStrings = MutableStack<String>( "Ding", "Dong" )
	println( stackStrings.size() ) 
	stackStrings.push( "Ting" )
	stackStrings.push( "Tong" )
	println( stackStrings.size() ) 
	println( stackStrings.pop() )	
}

//_____________________________________________________


class Temperature(var tempInCelsius: Float)

// Extension Properties 
var Temperature.tempInFahrenheit: Float
    get() = (tempInCelsius * 9 / 5) + 32
    set(value) {
        tempInCelsius = (value - 32) * 5 / 9
    }

fun playWithExtensionProperties() {
    val temp = Temperature(32f)
	println( temp.tempInFahrenheit )

	temp.tempInFahrenheit = 90f
	println( temp.tempInCelsius )
}

//_____________________________________________________

// Generic Extention Property

val <T> List<T>.penultimate: T
	get() = this[ size - 2 ]


fun playWithGenericProperty() {
	val list = listOf( 10, 20, 30, 40)
	println( "Value : ${ list.penultimate }")

	val listAgain = listOf( "Ding", "Dong", "Ting", "Tong")
	println( "Value : ${ listAgain.penultimate }")
}

//_____________________________________________________

open class Animal( val type : String  ) 
open class Pet( val name : String, type: String ) : Animal( type )

class Cat( name : String, type: String ) : Pet( name, type ) 
open class Dog( name : String, type: String ) : Pet( name, type ) 
class GermanShaperd( name : String, type: String ) : Dog( name, type ) 

fun chooseFavoriteNonGeneric( pets: List<Pet> ) : Pet {
	val random = Random()
    val favorite = pets[ random.nextInt( pets.size ) ]
    println("${favorite.name} is the favorite")
    return favorite
}

fun <T : Pet> chooseFavorite(pets: List<T> ): T {
	val random = Random()
    val favorite = pets[ random.nextInt( pets.size ) ]
    println("${favorite.name} is the favorite")
    return favorite
}

fun playWithChooseFavorite() {
	val cats: List<Cat> = listOf( Cat("Whiskers", "Cat"), Cat("Rosie", "Cat") )
	val favorite = chooseFavorite( cats )
	println( "Favorite Name : ${ favorite.name }" )

	val catsAgain: List<Cat> = listOf( Cat("Whiskers", "Cat"), Cat("Rosie", "Cat") )
	val favoriteAgain = chooseFavoriteNonGeneric( catsAgain )
	println( "Favorite Name : ${ favoriteAgain.name }" )

	val animals: List<Animal> = listOf( Animal("Fish"), Animal("Bird"), Animal("Mammal") )
	for (animal in animals) println( animal.type )
 	// error: type mismatch: inferred type is Animal but Pet was expected
	// val favoriteAgain = chooseFavorite( animals )
	// print( favoriteAgain )
}

//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
//_____________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE FLAG!!!

fun main( ) {
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}
