
#include <stdio.h>

//_______________________________________________________

typedef struct human_type  {
	int id;
	char name[100];
	void ( *dance )();
} Human;

void doBhangra() 	{ printf("\nOyee Hoyee!!!..."); 	}
void doHipHop() 	{ printf("\nHip Hop!!!..."); 		}

void playWithHuman() {
				// Constructor	
	Human gabbar = { 420, "Gabbar Singh", doBhangra };

	printf("\nID: %d", gabbar.id );
	printf("\nName: %s", gabbar.name );
	gabbar.dance();

	Human basanti = { 100, "Basanti", doHipHop };

	printf("\nID: %d", basanti.id );
	printf("\nName: %s", basanti.name );
	basanti.dance();
}

//_______________________________________________________

int sum( int a, int b ) { return a + b; }
int sub( int a, int b ) { return a - b; }

// Polymorphic Functions
//		Using Mechanims: By Passing Behaviour To Behaviour
int calulator( int a, int b, int (*operation)(int, int ) ) {
	return operation( a, b );
}

void playWithCalculator() {
	int a = 40;
	int b = 10;
	int result = 0;

	result = calulator( a, b, sum );
	printf("\nResult : %d", result );

	result = calulator( a, b, sub );
	printf("\nResult : %d", result );
}


//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________

void main() {
	printf("\n\nFunction: playWithHuman");
	playWithHuman();

	printf("\n\nFunction: playWithCalculator");
	playWithCalculator();

	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
}


