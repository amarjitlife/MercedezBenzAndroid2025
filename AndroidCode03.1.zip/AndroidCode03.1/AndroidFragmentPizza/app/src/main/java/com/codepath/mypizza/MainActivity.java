package com.codepath.mypizza;

import android.content.res.Configuration;
import android.os.Bundle;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.Toast;

import com.codepath.mypizza.fragments.PizzaDetailFragment;
import com.codepath.mypizza.fragments.PizzaMenuFragment;

public class MainActivity extends AppCompatActivity  implements
        PizzaMenuFragment.OnItemSelectedListener {

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);

    Log.d("MainActivity",
            getResources().getConfiguration().orientation + "");

    // When Apps Runs First Type
    // saveInstanceState Will Be mull
    if (savedInstanceState == null) {
      // Instance of first fragment
      PizzaMenuFragment pizzaMenuFragment = new PizzaMenuFragment();

      // Add Fragment to FrameLayout (flContainer), using FragmentManager
      FragmentTransaction ft = getSupportFragmentManager().beginTransaction();// begin  FragmentTransaction
      ft.add(R.id.flContainer, pizzaMenuFragment);                                // add    Fragment
      ft.commit();                                                            // commit FragmentTransaction
    }

    if(getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE){
      PizzaDetailFragment pizzaDetailFragment = new PizzaDetailFragment();
      Bundle args = new Bundle();
      args.putInt("position", 0);
      pizzaDetailFragment.setArguments(args);          // (1) Communicate with Fragment using Bundle
      FragmentTransaction ft2 = getSupportFragmentManager().beginTransaction();// begin  FragmentTransaction
      ft2.add(R.id.flContainer2, pizzaDetailFragment);                               // add    Fragment
      ft2.commit();                                                            // commit FragmentTransaction
    }
  }

  @Override
  public void onPizzaItemSelected(int position) {
    Toast.makeText(this, "Called By Fragment A: position - "+ position, Toast.LENGTH_SHORT).show();

    // Load Pizza Detail Fragment
    PizzaDetailFragment pizzaDetailFragment = new PizzaDetailFragment();

    Bundle args = new Bundle();
    args.putInt("position", position);
    pizzaDetailFragment.setArguments(args);          // (1) Communicate with Fragment using Bundle

    if(getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE){
      getSupportFragmentManager()
          .beginTransaction()
          .replace(R.id.flContainer2, pizzaDetailFragment) // replace flContainer
          //.addToBackStack(null)
          .commit();
    } else { // PORTRAIT Orientation
      getSupportFragmentManager()
          .beginTransaction()
          .replace(R.id.flContainer, pizzaDetailFragment) // replace flContainer
          .addToBackStack(null)
          .commit();
    }
  }
}
