
#include <stdio.h>

#include <unistd.h> // For fork(), getpid(), getppid()
#include <sys/types.h> // For pid_t



//_______________________________________________________

typedef struct human_type  {
	int id;
	char name[100];
	void ( *dance )();
} Human;

void doBhangra() 	{ printf("\nOyee Hoyee!!!..."); 	}
void doHipHop() 	{ printf("\nHip Hop!!!..."); 		}

void playWithHuman() {
				// Constructor	
	Human gabbar = { 420, "Gabbar Singh", doBhangra };

	printf("\nID: %d", gabbar.id );
	printf("\nName: %s", gabbar.name );
	gabbar.dance();

	Human basanti = { 100, "Basanti", doHipHop };

	printf("\nID: %d", basanti.id );
	printf("\nName: %s", basanti.name );
	basanti.dance();
}

//_______________________________________________________

int sum( int a, int b ) { return a + b; }
int sub( int a, int b ) { return a - b; }

// Polymorphic Functions
//		Using Mechanims: By Passing Behaviour To Behaviour
int calulator( int a, int b, int (*operation)(int, int ) ) {
	return operation( a, b );
}

void playWithCalculator() {
	int a = 40;
	int b = 10;
	int result = 0;

	result = calulator( a, b, sum );
	printf("\nResult : %d", result );

	result = calulator( a, b, sub );
	printf("\nResult : %d", result );
}


//_______________________________________________________

void playWithTypes() {
	// Array Of Pointers 
	void * something[5] = { };

	char ch = 'A';
	int a = 20;
	float f = 99.99;
	char thakur[10] = "Thakur";

	Human gabbar = { 420, "Gabbar Singh" };

	something[0] = &ch;
	something[1] = &a;
	something[2] = &f;
	something[3] = thakur;
	something[4] = &gabbar;

	printf("\nValue[0]: %d", *( (int * )(something[0]) ) );
	printf("\nValue[1]: %c", *( (char *) (something[1]) ) );

	printf("\nValue[0]: %f", *( (float * )(something[1]) ) );
	printf("\nValue[1]: %d", *( (int *) (something[2]) ) );	
}


//_________________________________________________________


int playWithProcesses() {
    pid_t child_pid;

    printf("Parent process before fork: PID = %d\n", getpid());

    // Create a child process
    child_pid = fork();

    if (child_pid == -1) {
        // Error handling for fork failure
        perror("fork failed");
        return 1; // Indicate an error
    } else if (child_pid == 0) {
        // This code block is executed by the child process
        printf("Child process: PID = %d, Parent PID = %d\n", getpid(), getppid());
    } else {
        // This code block is executed by the parent process
        printf("Parent process after fork: PID = %d, Child PID = %d\n", getpid(), child_pid);
    }

    while( 1 ) { }

    printf("This line is executed by both parent and child: PID = %d\n", getpid());

    return 0; // Indicate successful execution
}

//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________

void main() {
	printf("\n\nFunction: playWithHuman");
	playWithHuman();

	printf("\n\nFunction: playWithCalculator");
	playWithCalculator();

	printf("\n\nFunction: playWithTypes");
	playWithTypes();

	printf("\n\nFunction: playWithProcesses");
	playWithProcesses();
	

	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
	// printf("\n\nFunction: ");
}


