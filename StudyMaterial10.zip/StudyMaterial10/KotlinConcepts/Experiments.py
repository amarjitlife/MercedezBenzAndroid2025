
#________________________________________________
#________________________________________________

files = ["file1.txt", "file2.txt" ]

words = {}

for file in files:
	for line in open(file):
		for word in line.split():
			words[ word ] = words.get( word, 0 ) + 1

print( words )

#________________________________________________
#________________________________________________

def numberGenerator( maximum ) :
	numbers = []
	for number in range(1, maximum):
		numbers.append( number )
	return numbers

output = numberGenerator( 10 )
print( output )

#________________________________________________

def numberGeneratorAgain( maximum ) :
	print("Entered Function...")
	numbers = []	
	for number in range(1, maximum):
		yield number
		print("Continue Execution...")
	
	print("Exited Function...")


generator = numberGeneratorAgain( 10 )

for number in generator:
	print( number )

#________________________________________________
#________________________________________________
#________________________________________________

