
/*
kotlinc -include-runtime Hello.kt -d hello.jar
java -jar nature.jar
*/

//_______________________________________________________

fun collectionsInKotlin() {
	// BEST PRACTICE: Use Kotlin APIs
	// Kotlin APIs 
	//		Implemented As Extension Functions On Java Collections
	val hset 	= hashSetOf( 10, 20, 70, 100 )
	val list 	= arrayListOf( 10, 20, 70, 100 )
	val map 	= hashMapOf( 1 to "One", 10 to "Ten")

	println( hset.javaClass )
	println( list.javaClass )
	println( map.javaClass )

	val names = listOf("Gabbar Singh", "Basanti", "Samba", "Jay", "Veeru")
	println( names.javaClass )
}

//_______________________________________________________
// Generics/Templates
//		It's Code To Generate Code
//		Directives To Compiler To Generate Code 
//			By Substituting Type At Compile Time

// T Is Type Placeholder
//		T Will Get Substituted With Type At Compile Time

fun <T> joinToString(
	collection: Collection<T>,
	separator: String,
	prefix: String,
	postfix: String
) : String {

	val result = StringBuilder( prefix )

	for( (index, element) in collection.withIndex() ) {
		if ( index > 0 ) result.append( separator )
		result.append( element )
	}
	result.append( postfix )
	return result.toString()
}

/*
// Compiler Will Generate Following Code
//		By Substiting T Place Holder
fun joinToStringString(
	collection: Collection<String>,
	separator: String,
	prefix: String,
	postfix: String
) : String {

	val result = StringBuilder( prefix )

	for( (index, element) in collection.withIndex() ) {
		if ( index > 0 ) result.append( separator )
		result.append( element )
	}
	result.append( postfix )
	return result.toString()
}

fun joinToStringInteger(
	collection: Collection<Integer>,
	separator: String,
	prefix: String,
	postfix: String
) : String {

	val result = StringBuilder( prefix )

	for( (index, element) in collection.withIndex() ) {
		if ( index > 0 ) result.append( separator )
		result.append( element )
	}
	result.append( postfix )
	return result.toString()
}
*/


fun playWithJoinToString() {
	//			ArrayList<String> Type Inferred At Compile Time
	val names = listOf("Gabbar Singh", "Basanti", "Samba", "Jay", "Veeru")
	println( joinToString( names, " # ", "[", "]") )

	//			HashSet<Integer> Type Inferred At Compile Time
	var numbers = hashSetOf( 10, 20, 30, 40, 50 )
	println( joinToString( numbers, " # ", "[", "]") )
}

//_______________________________________________________

fun lastChar( string: String ): Char {
	return string.get( string.length - 1 )
}

// Extension Function On Type String
fun String.lastCharacter( ): Char {
	return this.get( this.length - 1 )
}

fun playWithLastCharacter() {
	var character = lastChar("Welcome To India!")
	println( character )

	character = lastChar("Ding Dong$#")
	println( character )

	// Extension Function Behaves Like Member Functions
	character = "Welcome To India!".lastCharacter()
	println( character )

	character = "Ding Dong$#".lastCharacter()
	println( character )
}


//_______________________________________________________

fun <T> Collection<T>.joinToStringExtension(
	separator: String,
	prefix: String,
	postfix: String
) : String {

	val result = StringBuilder( prefix )

	for( (index, element) in this.withIndex() ) {
		if ( index > 0 ) result.append( separator )
		result.append( element )
	}
	result.append( postfix )
	return result.toString()
}

fun playWithJoinToStringExtension() {
	//			ArrayList<String> Type Inferred At Compile Time
	val names = listOf("Gabbar Singh", "Basanti", "Samba", "Jay", "Veeru")
	println( names.joinToStringExtension(" # ", "[", "]") )

	//			HashSet<Integer> Type Inferred At Compile Time
	var numbers = hashSetOf( 10, 20, 30, 40, 50 )
	println( numbers.joinToStringExtension(" # ", "[", "]") )
}

//_______________________________________________________

// Follow Agreed Conventions and Design In Your Team
fun Collection<String>.join(
	separator: String,
	prefix: String,
	postfix: String
) = joinToStringExtension( separator, prefix, postfix )

fun playWithJoin() {
	//			ArrayList<String> Type Inferred At Compile Time
	val names = listOf("Gabbar Singh", "Basanti", "Samba", "Jay", "Veeru")
	println( names.join(" # ", "[", "]") )

	//			HashSet<Integer> Type Inferred At Compile Time
	// var numbers = hashSetOf( 10, 20, 30, 40, 50 )
	// println( numbers.join(" # ", "[", "]") )
}

//_______________________________________________________

fun moveTowardsZero( start: Int ) : Int {
	val something = "Local Something"

	// Local Function: 
	//		Function Defined Inside Another Function
	//		Private To Outside Context/Enclosing Function
	fun moveForward( start: Int ) : Int {
		println( something )
		return start + 1
	}

	fun moveBackward( start : Int ) = start - 1

	return if ( start > 0 ) moveBackward( start ) else moveForward( start )
}

fun playWtihLocalFunctions() {
	println( moveTowardsZero( 10 ))
	println( moveTowardsZero( -10 ))
}

//_______________________________________________________

class User( val id : Int, val name: String, val address: String )

fun saveUser( user: User ) {
	// Validation
	if ( user.name.isEmpty() ) {
		throw IllegalArgumentException("Can't Save User ${user.id}: Empty Name")
	}

	if ( user.address.isEmpty() ) {
		throw IllegalArgumentException("Can't Save User ${user.id}: Empty Address")
	}

	// Save User To Database...
	println("Saving USer....")
}

//_______________________________________________________

fun saveUserBetter( user: User ) {
	// Validation

	fun validate( user: User, value: String, fieldName: String ) {
		if ( value.isEmpty() ) {
			throw IllegalArgumentException("Can't Save User ${user.id}: Empty $fieldName")
		}		
	}

	validate( user, user.name, "Name")
	validate( user, user.address, "Address")

	// Save User To Database...
	println("Saving USer....")
}

//_______________________________________________________

fun User.save() {
	// Validation

	fun validate( user: User, value: String, fieldName: String ) {
		if ( value.isEmpty() ) {
			throw IllegalArgumentException("Can't Save User ${this.id}: Empty $fieldName")
		}		
	}

	validate( this, this.name, "Name")
	validate( this, this.address, "Address")

	// Save User To Database...
	println("Saving USer....")
}

//_______________________________________________________

fun User.saveAgain() { // Enclosing Context
	// Validation
	val outerThis = this
	fun validate( value: String, fieldName: String ) { // Enclosed Context
		println( this.name )
		if ( value.isEmpty() ) {
			throw IllegalArgumentException("Can't Save User ${outerThis.id}: Empty $fieldName")
		}		
		// saveAgain()
	}

	validate( this.name, "Name")
	validate( this.address, "Address")

	// Save User To Database...
	println("Saving USer....")
}

fun playWithSaveUser() {
	val gabbar = User( 420, "Gababr Singh", "Ramgarh")

	saveUser( gabbar )
	saveUserBetter( gabbar )

	gabbar.save()
	gabbar.saveAgain()
}


//_______________________________________________________

fun main() {
	println("\nFunction: collectionsInKotlin")
	collectionsInKotlin()

	println("\nFunction: playWithJoinToString")
	playWithJoinToString()

	println("\nFunction: playWithLastCharacter")
	playWithLastCharacter()

	println("\nFunction: playWithJoinToStringExtension")
	playWithJoinToStringExtension()

	println("\nFunction: playWithJoin")
	playWithJoin()

	println("\nFunction: playWtihLocalFunctions")	
	playWtihLocalFunctions()

	println("\nFunction: playWithSaveUser")
	playWithSaveUser()

	// println("\nFunction: ")
	// println("\nFunction: ")	
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")	
}




