/*
kotlinc 04KotlinMoreClasses.kt -include-runtime -d moreClasses.jar
java -jar moreClasses.jar
*/

package learnKotlin

import java.util.Comparator
import java.io.File
// import java.util.Comparator

//_______________________________________________________
//					Primary Constructor
data class Grade(val letter: Char, val points: Double, val credits: Double)

//					Primary Constructor
open class Person constructor(var firstName: String, var lastName: String) {
    // val fullName = "$firstName $lastName"

    fun fullName() = "$firstName $lastName"
}

open class Student(
    // var firstName: String, 
    // var lastName: String, 
    firstName: String, 
    lastName: String, 
    var grades: MutableList<Grade> = mutableListOf<Grade>()
) : Person(firstName, lastName) {
    open fun recordGrade(grade: Grade) {
        grades.add(grade)
    }
}

fun playWithClassesAndObjects() {
    val john = Person(firstName = "Johnny", lastName = "Appleseed")
    val jane = Student(firstName = "Jane", lastName = "Appleseed")

    john.fullName() // Johnny Appleseed
    jane.fullName() // Jane Appleseed

    val history = Grade(letter = 'B', points = 9.0, credits = 3.0)
    jane.recordGrade(history)
}

//_______________________________________________________


open class BandMember(firstName: String, lastName: String) : Student(firstName, lastName) {
    // open val minimumPracticeTime: Int
    //     get() { return 2 }

    open val minimumPracticeTime: Int = 2
}

class OboePlayer(firstName: String, lastName: String) : BandMember(firstName, lastName) {
    // override val minimumPracticeTime: Int
    // 	get() { super.minimumPracticeTime * 2 }

    // override val minimumPracticeTime: Int
    // 	get() = super.minimumPracticeTime * 2 

    override val minimumPracticeTime: Int = super.minimumPracticeTime * 2 
}

fun phonebookName(person: Person): String {
    return "${person.lastName}, ${person.firstName}"
}

fun playWithPhoneBookName() {
    val person = Person(firstName = "Johnny", lastName = "Appleseed")
    val oboePlayer = OboePlayer(firstName = "Jane", lastName = "Appleseed")

    phonebookName(person) // Appleseed, Johnny
    phonebookName(oboePlayer) // Appleseed, Jane
}

fun playWithRuntimeTypeCheck() {
    // Runtime hierarchy checks
    val oboePlayer = OboePlayer(firstName = "Jane", lastName = "Appleseed")
    var hallMonitor = Student(firstName = "Jill", lastName = "Bananapeel")

    hallMonitor = oboePlayer

    println(hallMonitor is OboePlayer) // true, since assigned it to oboePlayer
    println(hallMonitor !is OboePlayer) // also have !is for "not-is"
    println(hallMonitor is Person) // true, because Person is ancestor of OboePlayer

    // (oboePlayer as Student).minimumPracticeTime // Error: No longer a band member!

    println((hallMonitor as? BandMember)?.minimumPracticeTime) // > 4
}

// ____________________________________________________


class StudentAthlete(
    firstName: String, 
    lastName: String
) : Student(firstName, lastName) {
    val failedClasses = mutableListOf<Grade>()

    override fun recordGrade(grade: Grade) {
        super.recordGrade(grade)

        if (grade.letter == 'F') {
            failedClasses.add(grade)
        }
    }

    val isEligible: Boolean
        get() = failedClasses.size < 3
}

fun playWithStudentAthlete() {
    val math = Grade(letter = 'B', points = 9.0, credits = 3.0)
    val science = Grade(letter = 'F', points = 9.0, credits = 3.0)
    val physics = Grade(letter = 'F', points = 9.0, credits = 3.0)
    val chemistry = Grade(letter = 'F', points = 9.0, credits = 3.0)

    val dom = StudentAthlete(firstName = "Dom", lastName = "Grady")
    dom.recordGrade(math)
    dom.recordGrade(science)
    dom.recordGrade(physics)
    println("${dom.fullName()} is ${if (dom.isEligible) "eligible" else "ineligible"}") // eligible
    dom.recordGrade(chemistry)
    println("${dom.fullName()} is ${if (dom.isEligible) "eligible" else "ineligible"}") // ineligible
}

// ____________________________________________________

abstract class Mammal(val birthDate: String) {
    abstract fun consumeFood()
}

class Human(birthDate: String) : Mammal(birthDate) {
    override fun consumeFood() {
        // ...
    }
    
    fun createBirthCertificate() {
        // ...
    }
}

fun playWithHumanAndMammal() {
    val human = Human("1/1/2000")

    // Error: Cannot create an instance of an abstract class
//  val mammal = Mammal("1/1/2000") 
}

//_______________________________________________________

// Secondary Constructors
open class Shape {
    // Secondary Constructors
    constructor(size: Int) {
        // ...
    }
    // Secondary Constructors
    constructor(size: Int, color: String) : this(size) {
        // ...
    }
}

class Circle : Shape {
    // Secondary Constructors
    constructor(size: Int) : super(size) {
        // ...
    }

    // Secondary Constructors
    constructor(size: Int, color: String) : super(size, color) {
        // ...
    }
}

//_______________________________________________________
// In Java Inner Classes Are Default
// In Kotlin Nested Classes Are Default

// Nested Classes
// CANNOT Assess Outer Class/Context, Inside Class/Context
class Car1(val carName: String) { 
	val something = "Hello"

    fun doSomething() { 
        println(something)
    }

    class Engine(val engineName: String) { //
        override fun toString(): String {
            // Error cannot see outer scope, Hence Cann't Access carName
            // return "$engineName in a $carName" 
            return "$engineName"
        }
    }

    val engine = Engine("V6")
}

// Inner Class
// Can Assess Outer Class/Context, Inside Inner Class/Context
class Car2(val carName: String) { // Outer Class
	val something = "Hello"

    inner class Engine(val engineName: String) { // Inner Class
        override fun toString(): String {
            return "$engineName engine in a $carName"
        }
    }

    val engine1 = Engine("V6")
    val engine2 = this.Engine("V6")
}   

// Nested and Inner classes
fun playWithNestedAndInnerClasses() {
    val mazda1 = Car1("mazda")
    val mazdaEngine1 = Car1.Engine("rotary")
    println(mazdaEngine1) // > rotary engine in a mazda

    val mazda = Car2("mazda")
    val mazdaEngine = mazda.Engine("rotary")
    println(mazdaEngine) // > rotary engine in a mazda
}

//_______________________________________________________

class LengthCounter {
    var counter: Int = 0
        private set

    fun addWord(word: String) {
        counter += word.length
    }
}

fun changingAccessorVisibility() {
    val lengthCounter = LengthCounter()
    lengthCounter.addWord("Hi!")
    println(lengthCounter.counter)
}

//_______________________________________________________

// Visibility modifiers

data class Privilege(val id: Int, val name: String)

open class User(val username: String, private val id: String, protected var age: Int)

class PrivilegedUser(username: String, id: String, age: Int) : User(username, id, age) {
    private val privileges = mutableListOf<Privilege>()

    fun addPrivilege(privilege: Privilege) {
        privileges.add(privilege)
    }

    fun hasPrivilege(id: Int): Boolean {
        return privileges.map { it.id }.contains(id)
    }

    fun about(): String {
        // return "$username, $id" // Error: id is private
        return "$username, $age" // OK: age is protected
    }
}

fun playWithVisibilityModifiers() {
    val privilegedUser = PrivilegedUser(username = "sashinka", id = "1234", age = 21)
    val privilege = Privilege(1, "invisibility")
    privilegedUser.addPrivilege(privilege)
    println(privilegedUser.about()) // sashinka, 21
}


//_______________________________________________________

// import java.util.HashSet

class CountingSet<T>( val innerSet: MutableCollection<T> = HashSet<T>() ) 
    : MutableCollection<T> by innerSet {

    var objectsAdded = 0

    // Custom Methods Defintions
    override fun add(element: T): Boolean {
        objectsAdded++
        return innerSet.add(element)
    }

    // Custom Methods Defintions
    override fun addAll(elements: Collection<T>): Boolean {
        objectsAdded += elements.size
        return innerSet.addAll(elements)
    }
}

fun classDelegationUsingTheByKeyword() {
    val cset = CountingSet<Int>()
    cset.addAll(listOf(1, 1, 2))
    println("${cset.objectsAdded} objects were added, ${cset.size} remain")
}

//_______________________________________________________

// import java.util.Comparator
// import java.io.File

object CaseInsensitiveFileComparator : Comparator<File> {
    override fun compare(file1: File, file2: File): Int {
        return file1.path.compareTo(file2.path,
                ignoreCase = true)
    }
}

fun objectDeclarations() {
    println(CaseInsensitiveFileComparator.compare(
        File("/User"), File("/user")))
    val files = listOf(File("/Z"), File("/a"))
    println(files.sortedWith(CaseInsensitiveFileComparator))
}

//_______________________________________________________

// import java.util.Comparator

data class Person(val name: String) {
    object NameComparator : Comparator<Person> {
        override fun compare(p1: Person, p2: Person): Int =
            p1.name.compareTo(p2.name)
    }
}

fun objectDeclarations1() {
    val persons = listOf(Person("Bob"), Person("Alice"))
    println(persons.sortedWith(Person.NameComparator))
}

//_______________________________________________________

class A {
    var something = 99
    companion object {
        fun bar() {
            println( something )
            println("Companion object called")
        }
    }
}

fun companionObjects() {
    A.bar()
}

//_______________________________________________________

fun getFacebookName(accountId: Int) = "fb:$accountId"

class User5 private constructor(val nickname: String) {
    // Will Bind Members With Type Rather Than With Instance
    // In Java Using static Keyword
    companion object {
        fun newSubscribingUser(email: String) =
            User5(email.substringBefore('@'))

        fun newFacebookUser(accountId: Int) =
            User5(getFacebookName(accountId))
    }
}

fun companionObjects1() {
    val subscribingUser: User5 = User5.newSubscribingUser("bob@gmail.com")
    val facebookUser: User5 = User5.newFacebookUser(4)
    println(subscribingUser.nickname)
}

//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________

fun main() {
	println("\nFunction: playWithClassesAndObjects")
	playWithClassesAndObjects()

	// println("\nFunction: ")	
	// println("\nFunction: ")
	// println("\nFunction: ")	
	// println("\nFunction: ")
	// println("\nFunction: ")	
}

