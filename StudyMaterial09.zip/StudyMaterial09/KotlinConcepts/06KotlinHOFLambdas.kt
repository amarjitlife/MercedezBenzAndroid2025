
/*
kotlinc -include-runtime Hello.kt -d hello.jar
java -jar nature.jar
*/

//_______________________________________________________

// Function Type
//		(Int, Int) -> Int
fun sum( a: Int, b: Int ): Int  = a + b
fun sub( a: Int, b: Int ): Int  = a - b

// Higher Order Function
//		Functions Which Takes And/Or Returns Functions

// Polymorphic Function
//		Mechanism : Passing A Behaviour To Behaviour

// Function Type
//		(Int, Int, (Int, Int) -> Int) -> Int
fun calculator( a: Int, b: Int, operation: (Int, Int) -> Int ) : Int {
	return operation( a, b )
}

fun playWithCalculator() {
	val a = 50
	val b = 20
	var result: Int = 0

	result = calculator( a, b, ::sum ) // Configuring with ::sum
	println("Result : $result")

	result = calculator( a, b, ::sub ) // Configuring with ::sum
	println("Result : $result")

	// Lambda
	//		Anonmous Functions
	val sumLambda: (Int, Int) -> Int  = { a: Int, b: Int -> a + b }
	result = calculator( a, b, sumLambda ) // Configuring with sumLambda
	println("Result : $result")

	// Function Type (Int, Int) -> Int
	val subLambda = { a: Int, b: Int -> a - b }
	result = calculator( a, b, subLambda ) // Configuring with subLambda
	println("Result : $result")

	result = calculator( a, b, { a: Int, b: Int -> a * b } ) // Configuring with subLambda
	println("Result : $result")

	// Trailing Lamba Syntax
	result = calculator( a, b ) { a: Int, b: Int -> a * b } // Configuring with subLambda
	println("Result : $result")

	result = calculator( a, b ) { 
		a: Int, b: Int -> a * b 
	} // Configuring with subLambda
	println("Result : $result")
}

//_______________________________________________________

fun twoAndThree(operation: (Int, Int) -> Int) {
    val result = operation(2, 3)
    println("The result is $result")
}

fun callingFunctionsPassedAsArguments() {
    twoAndThree { a, b -> a + b }
    twoAndThree { a, b -> a * b }
}

//_______________________________________________________

data class Person(val name: String, val age: Int)

fun findTheMax(people: List<Person> ) {
    var max = 0
    var theMaximum: Person? = null

    for (person in people) {
        if ( person.age > max) {
            max = person.age
            theMaximum = person
        }
    }
    println(theMaximum)
}

fun playWithTheMax() {
    val people = listOf(Person("Alice", 29), Person("Bob", 31))
    findTheMax(people)
}

//_______________________________________________________

fun String.filter(predicate: (Char) -> Boolean): String {
    val sb = StringBuilder()
    for (index in 0 until length) {
        val element = get(index)
        if (predicate(element)) sb.append(element)
    }
    return sb.toString()
}

fun callingFunctionsPassedAsArguments1() {
    println("ab1c".filter { it in 'a'..'z' })
}

//_______________________________________________________


fun <T> Collection<T>.joinToStringDefault(
        separator: String = ", ",
        prefix: String = "",
        postfix: String = "",
        transform: (T) -> String = { it.toString() }
): String {
    val result = StringBuilder(prefix)

    for ((index, element) in this.withIndex()) {
        if (index > 0) result.append(separator)
        result.append(transform(element))
    }

    result.append(postfix)
    return result.toString()
}

fun joinToStringDefaultFunction() {
    val letters = listOf("Alpha", "Beta")

    //error: cannot choose among the following candidates 
    // without completing type inference: 
    println(letters.joinToStringDefault())

    println(letters.joinToStringDefault { it.lowercase() } )
    println(letters.joinToStringDefault(separator = "! ", postfix = "! ",
           transform = { it.lowercase() }))
}

//_______________________________________________________

enum class Delivery { STANDARD, EXPEDITED }

class Order(val itemCount: Int)

fun getShippingCostCalculator(delivery: Delivery): (Order) -> Double {
    if (delivery == Delivery.EXPEDITED) {
        return { order -> 6 + 2.1 * order.itemCount }
    }

    return { order -> 1.2 * order.itemCount }
}

fun returningFunctionsFromFunctions() {
    val calculator =
        getShippingCostCalculator(Delivery.EXPEDITED)
    println("Shipping costs ${calculator(Order(3))}")
}


//_______________________________________________________

data class Person1(
    val firstName: String,
    val lastName: String,
    val phoneNumber: String?
)

class ContactListFilters {
    var prefix: String = ""
    var onlyWithPhoneNumber: Boolean = false

    fun getPredicate(): (Person1) -> Boolean {
        val startsWithPrefix = { p: Person1 ->
            p.firstName.startsWith(prefix) || p.lastName.startsWith(prefix)
        }
        if (!onlyWithPhoneNumber) {
            return startsWithPrefix
        }
        return { startsWithPrefix(it)
                    && it.phoneNumber != null }
    }
}

fun returningFunctionsFromFunctions1() {
    val contacts = listOf(Person1("Dmitry", "Jemerov", "123-4567"),
                          Person1("Svetlana", "Isakova", null))
    val contactListFilters = ContactListFilters()
    with (contactListFilters) {
        prefix = "Dm"
        onlyWithPhoneNumber = true
    }
    println(contacts.filter(
        contactListFilters.getPredicate()))
}

// Function: returningFunctionsFromFunctions1
// [Person1(firstName=Dmitry, lastName=Jemerov, phoneNumber=123-4567)]

//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________

fun main() {
	println("\nFunction: playWithCalculator")
	playWithCalculator()

	println("\nFunction: returningFunctionsFromFunctions1")
	returningFunctionsFromFunctions1()

	// println("\nFunction: ")	
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")	
}




