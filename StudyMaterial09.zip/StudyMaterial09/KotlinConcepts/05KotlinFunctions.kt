


/*
kotlinc -include-runtime Hello.kt -d hello.jar
java -jar nature.jar
*/

//_______________________________________________________

// Function Type
//		(Int, Int) -> Int
fun sum( a: Int, b: Int ): Int  = a + b
fun sub( a: Int, b: Int ): Int  = a - b

// Function Type
//		(Int, Int, (Int, Int) -> Int) -> Int
fun calculator( a: Int, b: Int, operation: (Int, Int) -> Int ) : Int {
	return operation( a, b )
}

fun playWithCalculator() {
	val a = 50
	val b = 20
	var result: Int = 0

	result = calculator( a, b, ::sum )
	println("Result : $result")

	result = calculator( a, b, ::sub )
	println("Result : $result")
}

//_______________________________________________________

// Higher Order Function As Extension
//		Functions Which Takes Functions As Arguments

fun String.fliter(predicate : (Char) -> Boolean ) : String {
	val constructString = StringBuilder()
	for ( index in 0 until length ) {
		val element = get(index)

		if ( predicate( element ) ) constructString.append( element )
	}

	return constructString.toString()
}

fun playWithFilterExtension() {

	val something = "ab1d45deABCmmm"
	val criteriaLambda = { character : Char -> character in 'a'..'z' }
	val result = something.filter( criteriaLambda )	
	println( result )

	val result1 = something.filter( { character : Char -> character in 'a'..'z' } )
	println( result1 )

	val result2 = something.filter { character : Char -> character in 'a'..'z' } 
	println( result2 )

	val result3 = something.filter { 
		character : Char -> character in 'a'..'z' 
	} 
	println( result3 )
}

//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________
//_______________________________________________________

fun main() {
	println("\nFunction: playWithCalculator")
	playWithCalculator()

	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")	
	// println("\nFunction: ")
	// println("\nFunction: ")
	// println("\nFunction: ")	
}




